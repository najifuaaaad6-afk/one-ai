/**
 * توليد الصور — يعمل فقط عند ضبط خادم A1111؛ وإلا تُعرض حالة التعطيل بوضوح.
 */
import { useEffect, useState } from "react";
import { ImageOff, Loader2, Download } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useI18n } from "@/lib/i18n";
import { jfetch, formatBytes } from "@/lib/api";

interface Status {
  configured: boolean;
  endpoint: string;
}

interface HistoryItem {
  id: string;
  filename: string;
  size: number;
  url: string;
  created_at: number;
}

export default function ImageGen() {
  const { t } = useI18n();
  const [status, setStatus] = useState<Status | null>(null);
  const [prompt, setPrompt] = useState("");
  const [negative, setNegative] = useState("");
  const [width, setWidth] = useState(512);
  const [height, setHeight] = useState(512);
  const [quality, setQuality] = useState<"fast" | "balanced" | "high">("balanced");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [history, setHistory] = useState<HistoryItem[]>([]);

  useEffect(() => {
    jfetch<Status>("/api/imagegen/status").then(setStatus).catch(() => setStatus({ configured: false, endpoint: "" }));
    jfetch<HistoryItem[]>("/api/imagegen/history").then(setHistory).catch(() => undefined);
  }, []);

  async function generate() {
    if (!prompt.trim() || busy) return;
    setBusy(true);
    setError("");
    try {
      const res = await jfetch<{ id: string; url: string; size: number }>("/api/imagegen/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, negative, width, height, quality }),
      });
      setHistory((h) => [{ id: res.id, filename: `${res.id}.png`, size: res.size, url: res.url, created_at: Date.now() }, ...h]);
    } catch (err) {
      setError(err instanceof Error ? err.message : t("errorGeneric"));
    } finally {
      setBusy(false);
    }
  }

  const disabled = status && !status.configured;

  return (
    <AppShell>
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-3xl mx-auto px-4 py-8">
          <h1 className="text-2xl font-bold">{t("imagegenTitle")}</h1>
          <p className="text-sm opacity-60 mt-1">{t("imagegenSub")}</p>

          {disabled && (
            <div className="mt-6 rounded-2xl border border-dashed border-border p-6 flex flex-col items-center gap-3 text-center">
              <ImageOff size={36} className="opacity-40" />
              <p className="font-semibold">{t("imagegenDisabled")}</p>
              <p className="text-sm opacity-60 max-w-md">{t("imagegenDisabledHint")}</p>
            </div>
          )}

          {status?.configured && (
            <div className="mt-6 rounded-2xl border border-border bg-card p-5 space-y-4">
              <div>
                <Label>{t("prompt")}</Label>
                <TextareaAutosize value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder={t("promptPlaceholder")} />
              </div>
              <div>
                <Label>{t("negativePrompt")}</Label>
                <Input value={negative} onChange={(e) => setNegative(e.target.value)} dir="ltr" />
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <Label>{t("width")}</Label>
                  <Select value={String(width)} onValueChange={(v) => setWidth(Number(v))}>
                    <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                    <SelectContent>{[256, 384, 512, 640, 768, 1024].map((w) => <SelectItem key={w} value={String(w)}>{w}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>{t("height")}</Label>
                  <Select value={String(height)} onValueChange={(v) => setHeight(Number(v))}>
                    <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                    <SelectContent>{[256, 384, 512, 640, 768, 1024].map((h) => <SelectItem key={h} value={String(h)}>{h}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="col-span-2">
                  <Label>{t("quality")}</Label>
                  <Select value={quality} onValueChange={(v) => setQuality(v as typeof quality)}>
                    <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fast">{t("qualityFast")}</SelectItem>
                      <SelectItem value="balanced">{t("qualityBalanced")}</SelectItem>
                      <SelectItem value="high">{t("qualityHigh")}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Button className="w-full gap-2" onClick={() => void generate()} disabled={busy || !prompt.trim()}>
                {busy ? <Loader2 size={16} className="animate-spin" /> : null}
                {busy ? t("generating") : t("generate")}
              </Button>
              {error && <p className="text-sm text-destructive">{error}</p>}
            </div>
          )}

          {history.length > 0 && (
            <div className="mt-8">
              <h2 className="font-semibold mb-3">{t("imagegenHistory")}</h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {history.map((h) => (
                  <a key={h.id} href={h.url} download target="_blank" rel="noreferrer" className="group relative rounded-xl overflow-hidden border border-border bg-card">
                    <img src={h.url} alt={h.filename} className="w-full aspect-square object-cover" loading="lazy" />
                    <span className="absolute inset-x-0 bottom-0 bg-black/60 text-white text-[11px] px-2 py-1.5 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Download size={11} /> {formatBytes(h.size)}
                    </span>
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </AppShell>
  );
}

function TextareaAutosize(props: { value: string; onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void; placeholder: string }) {
  return (
    <textarea
      value={props.value}
      onChange={props.onChange}
      placeholder={props.placeholder}
      rows={3}
      dir="auto"
      className="w-full resize-none rounded-xl border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring"
    />
  );
}
