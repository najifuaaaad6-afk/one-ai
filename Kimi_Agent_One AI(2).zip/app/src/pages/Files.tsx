/**
 * صفحة الملفات — رفع/عرض/حذف + دخول مباشر للمحادثة مع الملف.
 */
import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router";
import { Upload, Trash2, FileText, FileType, MessageSquareQuote } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useI18n } from "@/lib/i18n";
import { jfetch, formatBytes } from "@/lib/api";
import type { FileView } from "@contracts/types";

export default function Files() {
  const { t } = useI18n();
  const navigate = useNavigate();
  const [files, setFiles] = useState<FileView[]>([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  async function refresh() {
    try {
      setFiles(await jfetch<FileView[]>("/api/files/"));
    } catch (err) {
      setError(err instanceof Error ? err.message : t("errorGeneric"));
    }
  }
  useEffect(() => {
    void refresh();
  }, []);

  async function upload(f: File) {
    setError("");
    setBusy(true);
    const fd = new FormData();
    fd.append("file", f);
    try {
      await jfetch("/api/files/upload", { method: "POST", body: fd });
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("errorGeneric"));
    } finally {
      setBusy(false);
    }
  }

  async function remove(id: string) {
    await jfetch(`/api/files/${id}`, { method: "DELETE" }).catch(() => undefined);
    await refresh();
  }

  function askAbout(f: FileView) {
    const text = f.kind === "image" ? t("askFile") : `${t("summarizeFile")}: ${f.filename}`;
    sessionStorage.setItem("oneai-prefill", JSON.stringify({ text: text === t("askFile") ? "اشرح محتوى هذه الصورة" : "", fileId: f.id, filename: f.filename }));
    navigate("/chat");
  }

  const kindLabel = { pdf: t("fileKindPdf"), text: t("fileKindText"), image: t("fileKindImage"), "image-gen": t("fileKindImage") };

  return (
    <AppShell>
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-3xl mx-auto px-4 py-8">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h1 className="text-2xl font-bold">{t("filesTitle")}</h1>
              <p className="text-sm opacity-60 mt-1">{t("filesSub")}</p>
            </div>
            <Button className="gap-1.5 shrink-0" disabled={busy} onClick={() => inputRef.current?.click()}>
              <Upload size={15} /> {t("uploadFile")}
            </Button>
          </div>
          {error && <p className="text-sm text-destructive mt-3">{error}</p>}

          <div className="mt-6 grid sm:grid-cols-2 gap-3">
            {files.length === 0 && <p className="text-sm opacity-50">{t("noFiles")}</p>}
            {files.map((f) => (
              <div key={f.id} className="rounded-2xl border border-border bg-card p-4 flex gap-3">
                {f.kind.startsWith("image") ? (
                  <img src={`/api/files/${f.id}/raw`} alt={f.filename} className="w-14 h-14 rounded-xl object-cover shrink-0" loading="lazy" />
                ) : (
                  <div className="w-11 h-11 rounded-xl bg-muted flex items-center justify-center shrink-0">
                    {f.kind === "pdf" ? <FileType size={20} className="opacity-60" /> : <FileText size={20} className="opacity-60" />}
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm truncate">{f.filename}</span>
                    <Badge variant="secondary" className="shrink-0">{kindLabel[f.kind as keyof typeof kindLabel] ?? f.kind}</Badge>
                  </div>
                  <p className="text-xs opacity-50 mt-0.5">{formatBytes(f.size)}</p>
                  <div className="flex gap-1 mt-2">
                    <Button size="sm" variant="outline" className="h-8 gap-1.5 text-xs" onClick={() => askAbout(f)}>
                      <MessageSquareQuote size={12} /> {f.kind.startsWith("image") ? t("askFile") : t("summarizeFile")}
                    </Button>
                    <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-destructive" onClick={() => void remove(f.id)} aria-label="delete">
                      <Trash2 size={13} />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      <input
        ref={inputRef}
        type="file"
        className="hidden"
        accept=".pdf,.txt,.md,image/png,image/jpeg,image/webp"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) void upload(f);
          e.target.value = "";
        }}
      />
    </AppShell>
  );
}
