/**
 * صفحة المحادثة — واجهة الدردشة الكاملة:
 * بث مباشر، Markdown، نسخ، إيقاف، إعادة توليد، مرفقات، إدارة المحادثات.
 */
import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Paperclip, Send, Square, Copy, Check, RotateCcw, Pencil, Trash2, Pin, PinOff, FileText, Image as ImageIcon, X } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { AppShell } from "@/components/AppShell";
import { Logo } from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useI18n } from "@/lib/i18n";
import { jfetch, readSSE } from "@/lib/api";

interface Attachment {
  id: string;
  filename: string;
  kind: string;
}

interface StreamState {
  messageId: string;
  conversationId: string;
  text: string;
  status: "streaming" | "done" | "error" | "stopped";
  error?: string;
}

export default function Chat() {
  const { t, lang } = useI18n();
  const navigate = useNavigate();
  const { id: paramId } = useParams<{ id: string }>();

  const [input, setInput] = useState("");
  const [pending, setPending] = useState<Attachment[]>([]);
  const [stream, setStream] = useState<StreamState | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [renameTarget, setRenameTarget] = useState<{ id: string; title: string } | null>(null);
  const [attachError, setAttachError] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const abortRef = useRef(false);

  const convList = trpc.conversations.list.useQuery();
  const current = trpc.conversations.get.useQuery(
    { id: paramId ?? "" },
    { enabled: !!paramId },
  );
  const utils = trpc.useUtils();

  const messages = current.data?.messages ?? [];

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages.length, stream?.text]);

  // قادم من صفحة الملفات: إرفاق الملف وتعبئة النص مسبقاً
  useEffect(() => {
    const raw = sessionStorage.getItem("oneai-prefill");
    if (!raw) return;
    sessionStorage.removeItem("oneai-prefill");
    try {
      const p = JSON.parse(raw) as { text?: string; fileId?: string; filename?: string };
      if (p.fileId) setPending([{ id: p.fileId, filename: p.filename ?? "file", kind: "text" }]);
      if (p.text) setInput(p.text);
    } catch {
      /* تجاهل */
    }
  }, []);

  async function handleFile(file: File) {
    setAttachError("");
    const fd = new FormData();
    fd.append("file", file);
    try {
      const res = await jfetch<Attachment>("/api/files/upload", { method: "POST", body: fd });
      setPending((p) => [...p, res]);
    } catch (err) {
      setAttachError(err instanceof Error ? err.message : t("errorGeneric"));
    }
  }

  async function send() {
    const content = input.trim();
    if (!content || stream?.status === "streaming") return;
    setInput("");
    const fileIds = pending.map((p) => p.id);
    setPending([]);
    abortRef.current = false;
    await runStream("/api/chat/send", { conversationId: paramId, content, fileIds });
  }

  async function runStream(url: string, payload: Record<string, unknown>, regenerateOf?: string) {
    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      let currentId = paramId ?? "";
      await readSSE(res, {
        onEvent: async (ev) => {
          if (ev.type === "start") {
            currentId = ev.conversationId as string;
            setStream({ messageId: ev.messageId as string, conversationId: currentId, text: "", status: "streaming" });
            if (!paramId) navigate(`/chat/${currentId}`, { replace: true });
          } else if (ev.type === "token") {
            setStream((s) => (s ? { ...s, text: s.text + (ev.token as string) } : s));
          } else if (ev.type === "done") {
            setStream((s) => (s ? { ...s, text: ev.content as string, status: "done" } : s));
          } else if (ev.type === "stopped") {
            setStream((s) => (s ? { ...s, status: "stopped" } : s));
          } else if (ev.type === "error") {
            setStream((s) => (s ? { ...s, status: "error", error: ev.message as string } : s));
          }
        },
      });
    } catch (err) {
      if (!abortRef.current) {
        setStream((s) => (s ? { ...s, status: "error", error: err instanceof Error ? err.message : t("errorGeneric") } : s));
      }
    } finally {
      await utils.conversations.list.invalidate();
      if (regenerateOf) {
        await utils.conversations.get.invalidate({ id: paramId ?? "" });
        setStream(null);
      } else {
        // أبقِ النص ظاهراً لحظة ثم حدّث من القاعدة
        setTimeout(() => {
          void utils.conversations.get.invalidate({ id: paramId ?? "" });
          setStream(null);
        }, 400);
      }
    }
  }

  async function stop() {
    if (!stream) return;
    abortRef.current = true;
    await jfetch("/api/chat/stop", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messageId: stream.messageId }),
    }).catch(() => undefined);
  }

  async function regenerate(messageId: string) {
    await runStream("/api/chat/regenerate", { messageId }, messageId);
  }

  async function copyText(text: string, id: string) {
    await navigator.clipboard.writeText(text).catch(() => undefined);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  }

  async function doRename() {
    if (!renameTarget?.title.trim()) return;
    await utils.client.conversations.rename.mutate({ id: renameTarget.id, title: renameTarget.title.trim() });
    setRenameTarget(null);
    await utils.conversations.list.invalidate();
  }

  const list = convList.data ?? [];
  const showWelcome = !paramId && messages.length === 0 && !stream;

  return (
    <AppShell>
      <div className="flex flex-1 min-h-0">
        {/* قائمة المحادثات — سطح المكتب */}
        <aside className="hidden lg:flex w-72 flex-col border-e border-border bg-card/50 shrink-0">
          <div className="p-3 border-b border-border text-xs font-semibold opacity-60">{t("navChat")}</div>
          <div className="flex-1 overflow-y-auto p-2 space-y-0.5">
            {list.length === 0 && <div className="text-sm opacity-50 p-3">{t("noConversations")}</div>}
            {list.map((c) => (
              <ConversationItem
                key={c.id}
                id={c.id}
                title={c.title || "…"}
                active={c.id === paramId}
                pinned={!!c.pinned}
                onOpen={() => navigate(`/chat/${c.id}`)}
                onRename={() => setRenameTarget({ id: c.id, title: c.title })}
                onDelete={async () => {
                  if (!window.confirm(t("confirmDelete"))) return;
                  await utils.client.conversations.delete.mutate({ id: c.id });
                  if (paramId === c.id) navigate("/chat");
                  await utils.conversations.list.invalidate();
                }}
                onPin={async () => {
                  await utils.client.conversations.pin.mutate({ id: c.id, pinned: !c.pinned });
                  await utils.conversations.list.invalidate();
                }}
              />
            ))}
          </div>
        </aside>

        {/* منطقة المحادثة */}
        <section className="flex-1 flex flex-col min-w-0">
          <div ref={scrollRef} className="flex-1 overflow-y-auto">
            {showWelcome ? (
              <div className="h-full flex flex-col items-center justify-center gap-4 px-6 text-center">
                <Logo size={64} />
                <h1 className="text-2xl font-bold">{t("welcomeTitle")}</h1>
                <p className="text-sm opacity-60 max-w-sm">{t("welcomeSub")}</p>
              </div>
            ) : (
              <div className="max-w-3xl mx-auto px-4 py-6 space-y-5">
                {messages
                  .filter((m) => !(m.role === "assistant" && m.content === "" && m.status !== "streaming"))
                  .map((m) => (
                  <MessageBubble
                    key={m.id}
                    id={m.id}
                    role={m.role}
                    content={m.content}
                    attachments={JSON.parse(m.attachments || "[]") as string[]}
                    status={m.status}
                    lang={lang}
                    copied={copiedId === m.id}
                    onCopy={() => copyText(m.content, m.id)}
                    onRegenerate={m.role === "assistant" ? () => regenerate(m.id) : undefined}
                  />
                ))}
                {stream && (
                  <div className="flex flex-col items-start gap-1">
                    <div className="chat-bubble-assistant w-full max-w-[85%]">
                      {stream.status === "streaming" && stream.text === "" ? (
                        <span className="flex items-center gap-1.5 py-1" aria-label={t("thinking")}>
                          <span className="typing-dot" />
                          <span className="typing-dot" />
                          <span className="typing-dot" />
                        </span>
                      ) : (
                        <Markdown text={stream.text} />
                      )}
                      {stream.status === "streaming" && (
                        <span className="inline-block w-0.5 h-4 bg-primary align-middle ms-0.5 animate-pulse" />
                      )}
                      {stream.status === "error" && (
                        <p className="text-destructive text-sm mt-1">{stream.error ?? t("errorGeneric")}</p>
                      )}
                      {stream.status === "stopped" && <p className="opacity-50 text-xs mt-1">■ {t("stop")}</p>}
                    </div>
                    <div className="flex gap-1">
                      {stream.status === "streaming" && (
                        <Button size="sm" variant="outline" onClick={stop} className="h-8 gap-1.5">
                          <Square size={13} /> {t("stop")}
                        </Button>
                      )}
                      {stream.text && (
                        <Button size="sm" variant="ghost" onClick={() => copyText(stream.text, "stream")} className="h-8 gap-1.5">
                          {copiedId === "stream" ? <Check size={13} /> : <Copy size={13} />} {copiedId === "stream" ? t("copied") : t("copy")}
                        </Button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* المرفقات المعلقة */}
          {pending.length > 0 && (
            <div className="max-w-3xl mx-auto w-full px-4 flex flex-wrap gap-2 pb-2">
              {pending.map((p) => (
                <span key={p.id} className="flex items-center gap-1.5 text-xs bg-muted rounded-lg px-2 py-1.5">
                  {p.kind === "image" ? <ImageIcon size={13} /> : <FileText size={13} />}
                  {p.filename}
                  <button onClick={() => setPending((arr) => arr.filter((x) => x.id !== p.id))} className="opacity-60 hover:opacity-100 p-1" aria-label="remove">
                    <X size={12} />
                  </button>
                </span>
              ))}
            </div>
          )}
          {attachError && <div className="max-w-3xl mx-auto w-full px-4 pb-2 text-xs text-destructive">{attachError}</div>}

          {/* صندوق الكتابة */}
          <div className="border-t border-border p-3 sm:p-4">
            <div className="max-w-3xl mx-auto flex items-end gap-2">
              <input
                ref={fileRef}
                type="file"
                className="hidden"
                accept=".pdf,.txt,.md,image/png,image/jpeg,image/webp"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) void handleFile(f);
                  e.target.value = "";
                }}
              />
              <Button
                variant="outline"
                size="icon"
                className="shrink-0 h-11 w-11 rounded-xl"
                onClick={() => fileRef.current?.click()}
                title={t("attachImagesNote")}
                aria-label={t("attach")}
              >
                <Paperclip size={18} />
              </Button>
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    void send();
                  }
                }}
                placeholder={t("typeMessage")}
                rows={Math.min(6, Math.max(1, input.split("\n").length))}
                className="flex-1 resize-none rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-ring min-h-[44px]"
              />
              {stream?.status === "streaming" ? (
                <Button variant="destructive" size="icon" className="shrink-0 h-11 w-11 rounded-xl" onClick={stop} aria-label={t("stop")}>
                  <Square size={16} />
                </Button>
              ) : (
                <Button size="icon" className="shrink-0 h-11 w-11 rounded-xl" onClick={() => void send()} disabled={!input.trim()} aria-label={t("send")}>
                  <Send size={18} className={lang === "ar" ? "-scale-x-100" : ""} />
                </Button>
              )}
            </div>
            <p className="max-w-3xl mx-auto text-[11px] opacity-40 mt-1.5 px-1">{t("attachImagesNote")}</p>
          </div>
        </section>
      </div>

      {/* حوار إعادة التسمية */}
      <Dialog open={!!renameTarget} onOpenChange={(o) => !o && setRenameTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t("rename")}</DialogTitle>
          </DialogHeader>
          <Input value={renameTarget?.title ?? ""} onChange={(e) => setRenameTarget((r) => r && { ...r, title: e.target.value })} />
          <DialogFooter>
            <Button variant="outline" onClick={() => setRenameTarget(null)}>{t("cancelAction")}</Button>
            <Button onClick={() => void doRename()}>{t("save")}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppShell>
  );
}

function ConversationItem(props: {
  id: string;
  title: string;
  active: boolean;
  pinned: boolean;
  onOpen: () => void;
  onRename: () => void;
  onDelete: () => void;
  onPin: () => void;
}) {
  const { t } = useI18n();
  return (
    <div
      className={`group flex items-center gap-1 rounded-xl px-3 py-2.5 cursor-pointer text-sm min-h-[44px] ${
        props.active ? "bg-primary text-primary-foreground" : "hover:bg-accent"
      }`}
      onClick={props.onOpen}
    >
      <span className="truncate flex-1">{props.title || "…"}</span>
      {props.pinned && <Pin size={12} className="opacity-60 shrink-0" />}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button
            className="opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-black/10 dark:hover:bg-white/10"
            onClick={(e) => e.stopPropagation()}
            aria-label="actions"
          >
            ⋯
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
          <DropdownMenuItem onClick={props.onRename}><Pencil size={14} className="me-2" />{t("rename")}</DropdownMenuItem>
          <DropdownMenuItem onClick={props.onPin}>
            {props.pinned ? <PinOff size={14} className="me-2" /> : <Pin size={14} className="me-2" />}
            {props.pinned ? t("unpin") : t("pin")}
          </DropdownMenuItem>
          <DropdownMenuItem className="text-destructive" onClick={props.onDelete}><Trash2 size={14} className="me-2" />{t("delete")}</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}

function MessageBubble(props: {
  id: string;
  role: string;
  content: string;
  attachments: string[];
  status: string;
  lang: string;
  copied: boolean;
  onCopy: () => void;
  onRegenerate?: () => void;
}) {
  const { t } = useI18n();
  const isUser = props.role === "user";
  return (
    <div className={`flex flex-col ${isUser ? "items-end" : "items-start"}`}>
      <div className={isUser ? "chat-bubble-user" : "chat-bubble-assistant w-full"} dir={isUser && props.lang === "ar" ? "rtl" : undefined}>
        {props.attachments.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mb-2 opacity-80">
            {props.attachments.slice(0, 3).map((a) => (
              <span key={a} className="text-[11px] bg-black/10 dark:bg-white/10 rounded px-1.5 py-0.5">{a.slice(0, 8)}…</span>
            ))}
          </div>
        )}
        {isUser ? <span className="whitespace-pre-wrap">{props.content}</span> : <Markdown text={props.content} />}
        {props.status === "error" && <p className="text-destructive text-xs mt-1">⚠ {t("errorGeneric")}</p>}
      </div>
      {!isUser && props.content && (
        <div className="flex gap-1 mt-1">
          <button onClick={props.onCopy} className="flex items-center gap-1 text-xs opacity-60 hover:opacity-100 px-2 py-1.5 min-h-[32px]">
            {props.copied ? <Check size={13} /> : <Copy size={13} />} {props.copied ? t("copied") : t("copy")}
          </button>
          {props.onRegenerate && (
            <button onClick={props.onRegenerate} className="flex items-center gap-1 text-xs opacity-60 hover:opacity-100 px-2 py-1.5 min-h-[32px]">
              <RotateCcw size={13} /> {t("regenerate")}
            </button>
          )}
        </div>
      )}
    </div>
  );
}

function Markdown({ text }: { text: string }) {
  return (
    <div className="md-body" dir="auto">
      <ReactMarkdown remarkPlugins={[remarkGfm]}>{text}</ReactMarkdown>
    </div>
  );
}
