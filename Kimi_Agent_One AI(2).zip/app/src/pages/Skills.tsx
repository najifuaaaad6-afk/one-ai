/**
 * صفحة Skills — إدارة كاملة: إضافة/تعديل/حذف/تفعيل/معرفة.
 */
import { useEffect, useRef, useState } from "react";
import { Plus, Pencil, Trash2, Upload, FileText, X } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { useI18n } from "@/lib/i18n";
import { jfetch } from "@/lib/api";
import type { SkillView } from "@contracts/types";

export default function Skills() {
  const { t, lang } = useI18n();
  const [skills, setSkills] = useState<SkillView[]>([]);
  const [editing, setEditing] = useState<Partial<SkillView> | null>(null);
  const [error, setError] = useState("");
  const [expanded, setExpanded] = useState<string | null>(null);
  const knowledgeRef = useRef<HTMLInputElement>(null);
  const knowledgeSkill = useRef<string>("");

  async function refresh() {
    try {
      setSkills(await jfetch<SkillView[]>("/api/skills"));
    } catch (err) {
      setError(err instanceof Error ? err.message : t("errorGeneric"));
    }
  }
  useEffect(() => {
    void refresh();
  }, []);

  async function save() {
    if (!editing?.name?.trim()) return;
    setError("");
    try {
      const payload = {
        name: editing.name,
        name_ar: editing.name_ar ?? "",
        description: editing.description ?? "",
        description_ar: editing.description_ar ?? "",
        prompt: editing.prompt ?? "",
      };
      if (editing.id) {
        await jfetch(`/api/skills/${editing.id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      } else {
        await jfetch("/api/skills", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      }
      setEditing(null);
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("errorGeneric"));
    }
  }

  async function toggle(id: string) {
    await jfetch(`/api/skills/${id}/toggle`, { method: "POST" });
    await refresh();
  }

  async function remove(id: string) {
    if (!window.confirm(t("deleteSkillConfirm"))) return;
    try {
      await jfetch(`/api/skills/${id}`, { method: "DELETE" });
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("errorGeneric"));
    }
  }

  async function uploadKnowledge(skillId: string, file: File) {
    setError("");
    const fd = new FormData();
    fd.append("file", file);
    try {
      await jfetch(`/api/skills/${skillId}/knowledge`, { method: "POST", body: fd });
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("errorGeneric"));
    }
  }

  return (
    <AppShell>
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-3xl mx-auto px-4 py-8">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h1 className="text-2xl font-bold">{t("skillsTitle")}</h1>
              <p className="text-sm opacity-60 mt-1">{t("skillsSub")}</p>
            </div>
            <Button className="gap-1.5 shrink-0" onClick={() => setEditing({ name: "", name_ar: "", description: "", description_ar: "", prompt: "" })}>
              <Plus size={15} /> {t("addSkill")}
            </Button>
          </div>
          <p className="text-xs opacity-50 mt-3">{t("activeSkills")}</p>
          {error && <p className="text-sm text-destructive mt-3">{error}</p>}

          <div className="mt-5 space-y-3">
            {skills.map((s) => (
              <div key={s.id} className="rounded-2xl border border-border bg-card p-4">
                <div className="flex items-center gap-3">
                  <Switch checked={!!s.enabled} onCheckedChange={() => void toggle(s.id)} aria-label="toggle" />
                  <div className="flex-1 min-w-0 cursor-pointer" onClick={() => setExpanded(expanded === s.id ? null : s.id)}>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold">{lang === "ar" && s.name_ar ? s.name_ar : s.name}</span>
                      <Badge variant="secondary">{s.builtin ? t("builtin") : t("custom")}</Badge>
                      <Badge variant={s.enabled ? "default" : "outline"}>{s.enabled ? t("enabled") : t("disabled")}</Badge>
                    </div>
                    <p className="text-xs opacity-60 mt-0.5 truncate">
                      {lang === "ar" && s.description_ar ? s.description_ar : s.description}
                    </p>
                  </div>
                  <Button size="icon" variant="ghost" className="h-9 w-9" onClick={() => setEditing({ ...s })} aria-label="edit">
                    <Pencil size={15} />
                  </Button>
                  {!s.builtin && (
                    <Button size="icon" variant="ghost" className="h-9 w-9 text-destructive" onClick={() => void remove(s.id)} aria-label="delete">
                      <Trash2 size={15} />
                    </Button>
                  )}
                </div>

                {expanded === s.id && (
                  <div className="mt-4 pt-4 border-t border-border">
                    <div className="flex items-center justify-between mb-2">
                      <Label className="text-sm font-semibold">{t("knowledge")}</Label>
                      <Button
                        size="sm"
                        variant="outline"
                        className="gap-1.5"
                        onClick={() => {
                          knowledgeSkill.current = s.id;
                          knowledgeRef.current?.click();
                        }}
                      >
                        <Upload size={13} /> {t("uploadKnowledge")}
                      </Button>
                    </div>
                    {s.knowledge.length === 0 ? (
                      <p className="text-xs opacity-50">{t("noKnowledge")}</p>
                    ) : (
                      <div className="space-y-1.5">
                        {s.knowledge.map((k) => (
                          <div key={k.id} className="flex items-center gap-2 text-sm bg-muted rounded-lg px-3 py-2">
                            <FileText size={14} className="opacity-60 shrink-0" />
                            <span className="truncate flex-1">{k.filename}</span>
                            <button
                              className="opacity-50 hover:opacity-100 p-1"
                              onClick={async () => {
                                await jfetch(`/api/skills/knowledge/${k.id}`, { method: "DELETE" });
                                await refresh();
                              }}
                              aria-label="remove knowledge"
                            >
                              <X size={13} />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      <input
        ref={knowledgeRef}
        type="file"
        className="hidden"
        accept=".txt,.md,.pdf"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f && knowledgeSkill.current) void uploadKnowledge(knowledgeSkill.current, f);
          e.target.value = "";
        }}
      />

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editing?.id ? t("rename") : t("addSkill")}</DialogTitle>
          </DialogHeader>
          {editing && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>{t("skillName")}</Label>
                  <Input value={editing.name ?? ""} onChange={(e) => setEditing({ ...editing, name: e.target.value })} />
                </div>
                <div>
                  <Label>{t("skillNameAr")}</Label>
                  <Input value={editing.name_ar ?? ""} onChange={(e) => setEditing({ ...editing, name_ar: e.target.value })} dir="rtl" />
                </div>
              </div>
              <div>
                <Label>{t("skillDesc")}</Label>
                <Input value={editing.description ?? ""} onChange={(e) => setEditing({ ...editing, description: e.target.value })} />
              </div>
              <div>
                <Label>{t("skillDescAr")}</Label>
                <Input value={editing.description_ar ?? ""} onChange={(e) => setEditing({ ...editing, description_ar: e.target.value })} dir="rtl" />
              </div>
              <div>
                <Label>{t("skillPrompt")}</Label>
                <Textarea rows={5} value={editing.prompt ?? ""} onChange={(e) => setEditing({ ...editing, prompt: e.target.value })} dir="auto" />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>{t("cancelAction")}</Button>
            <Button onClick={() => void save()} disabled={!editing?.name?.trim()}>{t("save")}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppShell>
  );
}
