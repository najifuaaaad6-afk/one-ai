/**
 * صفحة النماذج — الكتالوج مع تقدم تنزيل حقيقي (استطلاع كل ثانية أثناء التنزيل).
 */
import { useEffect, useRef, useState } from "react";
import { Download, Pause, Play, Trash2, XCircle, Cpu, HardDrive } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useI18n } from "@/lib/i18n";
import { jfetch, formatBytes } from "@/lib/api";
import type { ModelView } from "@contracts/types";

const LEVEL_KEYS = { Beta: "levelBeta", Alpha: "levelAlpha", Gamma: "levelGamma" } as const;

export default function Models() {
  const { t } = useI18n();
  const [models, setModels] = useState<ModelView[]>([]);
  const [error, setError] = useState("");
  const [speeds, setSpeeds] = useState<Record<string, number>>({});
  const lastRef = useRef<Record<string, { bytes: number; ts: number }>>({});

  async function refresh() {
    try {
      setModels(await jfetch<ModelView[]>("/api/models"));
    } catch (err) {
      setError(err instanceof Error ? err.message : t("errorGeneric"));
    }
  }

  useEffect(() => {
    void refresh();
    const timer = setInterval(() => void refresh(), 1000);
    return () => clearInterval(timer);
  }, []);

  // حساب السرعة من الفرق بين الاستطلاعات
  useEffect(() => {
    const now = Date.now();
    const next: Record<string, number> = {};
    for (const m of models) {
      if (m.status !== "downloading") continue;
      const last = lastRef.current[m.id];
      if (last && now > last.ts) {
        next[m.id] = Math.max(0, ((m.progress_bytes - last.bytes) / (now - last.ts)) * 1000);
      }
      lastRef.current[m.id] = { bytes: m.progress_bytes, ts: now };
    }
    if (Object.keys(next).length) setSpeeds((s) => ({ ...s, ...next }));
  }, [models]);

  async function action(id: string, act: "download" | "pause" | "resume" | "cancel" | "delete") {
    setError("");
    try {
      if (act === "delete") {
        if (!window.confirm(t("deleteModel") + "?")) return;
        await jfetch(`/api/models/${id}`, { method: "DELETE" });
      } else {
        await jfetch(`/api/models/${id}/${act}`, { method: "POST" });
      }
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("errorGeneric"));
    }
  }

  return (
    <AppShell>
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-3xl mx-auto px-4 py-8">
          <h1 className="text-2xl font-bold">{t("modelsTitle")}</h1>
          <p className="text-sm opacity-60 mt-1">{t("modelsSub")}</p>
          {error && <p className="text-sm text-destructive mt-3">{error}</p>}

          <div className="mt-6 space-y-4">
            {models.map((m) => (
              <div key={m.id} className="rounded-2xl border border-border bg-card p-5">
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h2 className="font-semibold text-lg">{m.name}</h2>
                      <Badge variant="secondary">{t(LEVEL_KEYS[m.level as keyof typeof LEVEL_KEYS] ?? "levelBeta")}</Badge>
                      {m.status === "installed" && <Badge className="bg-primary text-primary-foreground">{t("installed")}</Badge>}
                    </div>
                    <p className="text-xs opacity-50 mt-1 font-mono" dir="ltr">{m.repo}</p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {m.status === "none" || m.status === "error" ? (
                      <Button size="sm" className="gap-1.5" onClick={() => void action(m.id, "download")}>
                        <Download size={14} /> {t("download")}
                      </Button>
                    ) : m.status === "downloading" ? (
                      <>
                        <Button size="sm" variant="outline" className="gap-1.5" onClick={() => void action(m.id, "pause")}>
                          <Pause size={14} /> {t("pause")}
                        </Button>
                        <Button size="sm" variant="ghost" className="gap-1.5" onClick={() => void action(m.id, "cancel")}>
                          <XCircle size={14} /> {t("cancel")}
                        </Button>
                      </>
                    ) : m.status === "paused" ? (
                      <>
                        <Button size="sm" className="gap-1.5" onClick={() => void action(m.id, "resume")}>
                          <Play size={14} /> {t("resume")}
                        </Button>
                        <Button size="sm" variant="ghost" className="gap-1.5" onClick={() => void action(m.id, "cancel")}>
                          <XCircle size={14} /> {t("cancel")}
                        </Button>
                      </>
                    ) : m.status === "verifying" ? (
                      <Badge variant="outline">{t("verifying")}</Badge>
                    ) : (
                      <Button size="sm" variant="destructive" className="gap-1.5" onClick={() => void action(m.id, "delete")}>
                        <Trash2 size={14} /> {t("deleteModel")}
                      </Button>
                    )}
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 gap-3 text-sm">
                  <div className="flex items-center gap-2 opacity-70">
                    <HardDrive size={14} />
                    <span>{t("modelSize")}: {formatBytes(m.size_bytes)}</span>
                  </div>
                  <div className="flex items-center gap-2 opacity-70">
                    <Cpu size={14} />
                    <span>
                      {t("modelStatus")}:{" "}
                      {m.status === "installed" ? t("installed")
                        : m.status === "downloading" ? t("downloading")
                        : m.status === "paused" ? t("paused")
                        : m.status === "verifying" ? t("verifying")
                        : m.status === "error" ? t("downloadError")
                        : t("notInstalled")}
                    </span>
                  </div>
                  {m.status === "downloading" && speeds[m.id] > 0 && (
                    <div className="opacity-70">{t("downloadSpeed")}: {formatBytes(Math.round(speeds[m.id]))}/s</div>
                  )}
                </div>

                {(m.status === "downloading" || m.status === "paused" || m.status === "verifying") && (
                  <div className="mt-3">
                    <div className="flex justify-between text-xs opacity-60 mb-1">
                      <span>{t("modelProgress")}: {m.percent}%</span>
                      <span dir="ltr">{formatBytes(m.progress_bytes)} / {formatBytes(m.size_bytes)}</span>
                    </div>
                    <Progress value={m.percent} className="h-2" />
                  </div>
                )}
                {m.status === "error" && m.error && (
                  <p className="text-sm text-destructive mt-2">{m.error}</p>
                )}
              </div>
            ))}
          </div>
          <p className="text-xs opacity-50 mt-6">{t("downloadHint")}</p>
        </div>
      </div>
    </AppShell>
  );
}
