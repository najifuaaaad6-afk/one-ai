/**
 * الإعدادات — لغة، مظهر، ألوان، أداء، سيرفر خاص، توليد صور، تخزين، بيانات.
 */
import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { Check, Download, Trash2, Plug, PlugZap, Loader2 } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Separator } from "@/components/ui/separator";
import { useI18n } from "@/lib/i18n";
import { applyTheme, ACCENTS, type Accent } from "@/lib/theme";
import { jfetch, formatBytes } from "@/lib/api";

interface StorageInfo {
  dbBytes: number;
  filesBytes: number;
  modelsBytes: number;
  totalBytes: number;
  conversations: number;
  messagesCount: number;
  filesCount: number;
}

export default function Settings() {
  const { t, lang, setLang } = useI18n();
  const navigate = useNavigate();
  const settings = trpc.settings.getAll.useQuery();
  const setSetting = trpc.settings.set.useMutation();

  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const [accent, setAccent] = useState<Accent>("violet");
  const [contextLen, setContextLen] = useState(4096);
  const [threads, setThreads] = useState(4);
  const [engine, setEngine] = useState("local");
  const [serverUrl, setServerUrl] = useState("");
  const [serverKey, setServerKey] = useState("");
  const [serverModel, setServerModel] = useState("");
  const [imagegenEndpoint, setImagegenEndpoint] = useState("");
  const [storage, setStorage] = useState<StorageInfo | null>(null);
  const [checkResult, setCheckResult] = useState<{ ok: boolean; message?: string; models?: string[] } | null>(null);
  const [checking, setChecking] = useState(false);
  const [notice, setNotice] = useState("");

  useEffect(() => {
    const s = settings.data;
    if (!s) return;
    setTheme(s.theme === "light" ? "light" : "dark");
    setAccent((s.accent as Accent) || "violet");
    setContextLen(Number(s.context_length) || 4096);
    setThreads(Number(s.threads) || 4);
    setEngine(s.engine || "local");
    setServerUrl(s.remote_url ?? "");
    setServerKey("");
    setServerModel(s.remote_model ?? "");
    setImagegenEndpoint(s.imagegen_endpoint ?? "");
  }, [settings.data]);

  useEffect(() => {
    jfetch<StorageInfo>("/api/system/storage").then(setStorage).catch(() => undefined);
  }, []);

  function persist(key: string, value: string) {
    setSetting.mutate({ key, value });
    localStorage.setItem(`oneai-${key}`, value);
  }

  function changeTheme(v: "dark" | "light") {
    setTheme(v);
    applyTheme(v, accent);
    persist("theme", v);
  }

  function changeAccent(v: Accent) {
    setAccent(v);
    applyTheme(theme, v);
    persist("accent", v);
  }

  async function checkServer() {
    setChecking(true);
    setCheckResult(null);
    try {
      // احفظ الإعدادات أولاً ثم افحص
      await jfetch("/api/server/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: serverUrl, key: serverKey, model: serverModel }),
      });
      persist("remote_url", serverUrl);
      if (serverKey && serverKey !== "••••••") persist("remote_key", serverKey);
      persist("remote_model", serverModel);
      setCheckResult(await jfetch<{ ok: boolean; message?: string; models?: string[] }>("/api/server/check"));
    } catch (err) {
      setCheckResult({ ok: false, message: err instanceof Error ? err.message : t("errorGeneric") });
    } finally {
      setChecking(false);
    }
  }

  async function exportData() {
    const data = await jfetch<unknown>("/api/system/export", { method: "POST" });
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `oneai-export-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
  }

  async function wipe() {
    if (!window.confirm(t("deleteAllConfirm"))) return;
    await jfetch("/api/system/wipe", { method: "POST" });
    setNotice(t("deleteAllData") + " ✓");
    navigate(0);
  }

  return (
    <AppShell>
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-2xl mx-auto px-4 py-8 space-y-8">
          <h1 className="text-2xl font-bold">{t("settingsTitle")}</h1>
          {notice && <p className="text-sm text-primary">{notice}</p>}

          {/* اللغة والمظهر */}
          <section className="space-y-4">
            <h2 className="font-semibold">{t("appearance")}</h2>
            <div className="rounded-2xl border border-border bg-card p-5 space-y-4">
              <div className="flex items-center justify-between gap-4 flex-wrap">
                <Label>{t("language")}</Label>
                <Select value={lang} onValueChange={(v) => setLang(v as "ar" | "en")}>
                  <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ar">العربية</SelectItem>
                    <SelectItem value="en">English</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Separator />
              <div className="flex items-center justify-between gap-4 flex-wrap">
                <Label>{t("appearance")}</Label>
                <Select value={theme} onValueChange={(v) => changeTheme(v as "dark" | "light")}>
                  <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dark">{t("themeDark")}</SelectItem>
                    <SelectItem value="light">{t("themeLight")}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Separator />
              <div className="flex items-center justify-between gap-4 flex-wrap">
                <Label>{t("accentColor")}</Label>
                <div className="flex gap-2">
                  {(Object.keys(ACCENTS) as Accent[]).map((a) => (
                    <button
                      key={a}
                      onClick={() => changeAccent(a)}
                      className={`w-9 h-9 rounded-full border-2 transition-transform ${accent === a ? "border-foreground scale-110" : "border-transparent"}`}
                      style={{ background: `hsl(${ACCENTS[a].dark})` }}
                      aria-label={ACCENTS[a].label}
                      title={lang === "ar" ? ACCENTS[a].labelAr : ACCENTS[a].label}
                    />
                  ))}
                </div>
              </div>
            </div>
          </section>

          {/* الأداء */}
          <section className="space-y-4">
            <h2 className="font-semibold">{t("performance")}</h2>
            <div className="rounded-2xl border border-border bg-card p-5 space-y-5">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <Label>{t("contextLength")}</Label>
                  <span className="font-mono">{contextLen}</span>
                </div>
                <Slider value={[contextLen]} min={1024} max= {32768} step={1024} onValueChange={([v]) => { setContextLen(v); persist("context_length", String(v)); }} />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <Label>{t("cpuThreads")}</Label>
                  <span className="font-mono">{threads}</span>
                </div>
                <Slider value={[threads]} min={1} max={16} step={1} onValueChange={([v]) => { setThreads(v); persist("threads", String(v)); }} />
              </div>
              <p className="text-xs opacity-50">{t("gpuNote")}</p>
            </div>
          </section>

          {/* السيرفر الخاص */}
          <section className="space-y-4">
            <h2 className="font-semibold flex items-center gap-2">{t("serverSettings")}</h2>
            <div className="rounded-2xl border border-border bg-card p-5 space-y-4">
              <div className="flex items-center justify-between gap-4 flex-wrap">
                <Label>{t("runMode")}</Label>
                <Select
                  value={engine}
                  onValueChange={(v) => {
                    setEngine(v);
                    persist("engine", v);
                  }}
                >
                  <SelectTrigger className="w-52"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="local">{t("modeLocal")}</SelectItem>
                    <SelectItem value="remote">{t("modeRemote")}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Separator />
              <div className="space-y-3">
                <div>
                  <Label>{t("serverUrl")}</Label>
                  <Input value={serverUrl} onChange={(e) => setServerUrl(e.target.value)} placeholder={t("serverUrlPlaceholder")} dir="ltr" className="font-mono" />
                </div>
                <div>
                  <Label>{t("serverKey")}</Label>
                  <Input type="password" value={serverKey} onChange={(e) => setServerKey(e.target.value)} placeholder="sk-..." dir="ltr" className="font-mono" />
                </div>
                <div>
                  <Label>{t("serverModel")}</Label>
                  <Input value={serverModel} onChange={(e) => setServerModel(e.target.value)} placeholder="qwen2.5-7b-instruct" dir="ltr" className="font-mono" />
                </div>
                <div className="flex items-center gap-3 flex-wrap">
                  <Button variant="outline" className="gap-1.5" onClick={() => void checkServer()} disabled={checking || !serverUrl.trim()}>
                    {checking ? <Loader2 size={14} className="animate-spin" /> : <Plug size={14} />}
                    {t("checkConnection")}
                  </Button>
                  {checkResult && (
                    <span className={`flex items-center gap-1.5 text-sm ${checkResult.ok ? "text-green-600 dark:text-green-400" : "text-destructive"}`}>
                      {checkResult.ok ? <Check size={15} /> : <PlugZap size={15} />}
                      {checkResult.ok ? t("connected") : checkResult.message ?? t("connectionFailed")}
                    </span>
                  )}
                </div>
                {checkResult?.ok && checkResult.models && checkResult.models.length > 0 && (
                  <p className="text-xs opacity-60 font-mono" dir="ltr">{checkResult.models.join(", ")}</p>
                )}
              </div>
              <Separator />
              <div>
                <Label>{t("imagegenEndpoint")}</Label>
                <Input
                  value={imagegenEndpoint}
                  onChange={(e) => { setImagegenEndpoint(e.target.value); persist("imagegen_endpoint", e.target.value); }}
                  placeholder="http://192.168.1.5:7860"
                  dir="ltr"
                  className="font-mono"
                />
              </div>
            </div>
          </section>

          {/* التخزين */}
          <section className="space-y-4">
            <h2 className="font-semibold">{t("storage")}</h2>
            <div className="rounded-2xl border border-border bg-card p-5 space-y-3">
              {storage && (
                <>
                  <div className="flex justify-between text-sm"><span>{t("storageUsed")}</span><span className="font-mono">{formatBytes(storage.totalBytes)}</span></div>
                  <div className="flex justify-between text-sm opacity-70"><span>{t("conversationsCount")}</span><span className="font-mono">{storage.conversations}</span></div>
                  <div className="flex justify-between text-sm opacity-70"><span>{t("messagesCount")}</span><span className="font-mono">{storage.messagesCount}</span></div>
                  <div className="flex justify-between text-sm opacity-70"><span>{t("filesCount")}</span><span className="font-mono">{storage.filesCount}</span></div>
                  <Separator />
                </>
              )}
              <div className="flex gap-2 flex-wrap">
                <Button variant="outline" className="gap-1.5" onClick={() => void exportData()}>
                  <Download size={14} /> {t("exportData")}
                </Button>
                <Button variant="destructive" className="gap-1.5" onClick={() => void wipe()}>
                  <Trash2 size={14} /> {t("deleteAllData")}
                </Button>
              </div>
            </div>
          </section>

          <p className="text-xs opacity-40 text-center pb-4">One AI v0.1.0 — SQLite · يعمل محلياً</p>
        </div>
      </div>
    </AppShell>
  );
}
