import { useEffect } from "react";
import { Routes, Route, Navigate } from "react-router";
import { I18nProvider, useI18n } from "@/lib/i18n";
import { bootTheme } from "@/lib/theme";
import Chat from "@/pages/Chat";
import Models from "@/pages/Models";
import Skills from "@/pages/Skills";
import Files from "@/pages/Files";
import ImageGen from "@/pages/ImageGen";
import Settings from "@/pages/Settings";
import NotFound from "@/pages/NotFound";

function Boot() {
  const { ready } = useI18n();
  useEffect(() => {
    void bootTheme();
  }, []);
  if (!ready) {
    return (
      <div className="h-dvh flex items-center justify-center bg-background">
        <div className="flex gap-1" aria-label="loading">
          <span className="typing-dot" />
          <span className="typing-dot" />
          <span className="typing-dot" />
        </div>
      </div>
    );
  }
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/chat" replace />} />
      <Route path="/chat" element={<Chat />} />
      <Route path="/chat/:id" element={<Chat />} />
      <Route path="/models" element={<Models />} />
      <Route path="/skills" element={<Skills />} />
      <Route path="/files" element={<Files />} />
      <Route path="/imagegen" element={<ImageGen />} />
      <Route path="/settings" element={<Settings />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default function App() {
  return (
    <I18nProvider>
      <Boot />
    </I18nProvider>
  );
}
