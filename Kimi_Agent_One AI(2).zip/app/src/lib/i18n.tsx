/**
 * نظام الترجمة ثنائي اللغة (عربي RTL / إنجليزي LTR) مع حفظ الاختيار محلياً.
 */
import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Lang = "ar" | "en";

const dict = {
  ar: {
    appName: "One AI",
    tagline: "مساعدك الذكي — يعمل محلياً",
    navChat: "المحادثة",
    navModels: "النماذج",
    navSkills: "المهارات",
    navFiles: "الملفات",
    navImageGen: "توليد الصور",
    navSettings: "الإعدادات",
    newChat: "محادثة جديدة",
    noConversations: "لا توجد محادثات بعد",
    typeMessage: "اكتب رسالتك…",
    send: "إرسال",
    stop: "إيقاف",
    copy: "نسخ",
    copied: "تم النسخ",
    regenerate: "إعادة التوليد",
    thinking: "يفكر…",
    rename: "إعادة تسمية",
    delete: "حذف",
    pin: "تثبيت",
    unpin: "إلغاء التثبيت",
    confirmDelete: "هل تريد حذف هذه المحادثة نهائياً؟",
    attach: "إرفاق ملف",
    attachImagesNote: "يمكن إرفاق PDF أو TXT أو صور (PNG/JPG/WebP)",
    welcomeTitle: "كيف يمكنني مساعدتك اليوم؟",
    welcomeSub: "محادثات محفوظة محلياً — بياناتك لا تغادر جهازك",
    errorGeneric: "حدث خطأ. حاول مجدداً.",
    engineLocal: "المحرك المحلي",
    engineRemote: "السيرفر الخاص",
    disconnected: "غير متصل",
    modelsTitle: "النماذج",
    modelsSub: "نماذج GGUF مفتوحة المصدر — تُحمَّل وتُدار محلياً",
    levelBeta: "Beta — خفيف (~0.5GB)",
    levelAlpha: "Alpha — متوازن (1–2GB)",
    levelGamma: "Gamma — الأقوى (4–5GB)",
    download: "تنزيل",
    downloading: "جارٍ التنزيل…",
    pause: "إيقاف مؤقت",
    resume: "استئناف",
    cancel: "إلغاء",
    deleteModel: "حذف النموذج",
    installed: "مثبّت",
    notInstalled: "غير مثبّت",
    paused: "متوقف مؤقتاً",
    verifying: "جارٍ التحقق…",
    downloadError: "خطأ في التنزيل",
    modelSize: "الحجم",
    modelStatus: "الحالة",
    modelProgress: "التقدم",
    downloadHint: "بعد اكتمال التنزيل شغّل النموذج عبر سيرفر خاص (llama.cpp) من الإعدادات.",
    skillsTitle: "المهارات",
    skillsSub: "وسّع قدرات المساعد بمهارات ومعرفة مخصصة",
    addSkill: "مهارة جديدة",
    skillName: "الاسم",
    skillNameAr: "الاسم بالعربية",
    skillDesc: "الوصف",
    skillDescAr: "الوصف بالعربية",
    skillPrompt: "تعليمات النظام للمهارة",
    save: "حفظ",
    cancelAction: "إلغاء",
    enabled: "مفعّلة",
    disabled: "معطّلة",
    builtin: "مدمجة",
    custom: "مخصصة",
    knowledge: "ملفات المعرفة",
    uploadKnowledge: "رفع ملف معرفة (TXT/MD/PDF)",
    noKnowledge: "لا توجد ملفات معرفة",
    deleteSkillConfirm: "حذف هذه المهارة وكل معرفتها؟",
    filesTitle: "الملفات",
    filesSub: "مستنداتك المرفوعة — تُحلَّل محلياً وتُستخدم في المحادثات",
    uploadFile: "رفع ملف",
    noFiles: "لا توجد ملفات بعد",
    fileKindPdf: "PDF",
    fileKindText: "نص",
    fileKindImage: "صورة",
    summarizeFile: "تلخيص هذا الملف",
    askFile: "سؤال عن الملف",
    imagegenTitle: "توليد الصور",
    imagegenSub: "توليد صور بالذكاء الاصطناعي عبر نموذج محلي",
    prompt: "الوصف النصي",
    promptPlaceholder: "صورة لغروب الشمس فوق جبال ثلجية…",
    negativePrompt: "وصف سلبي (اختياري)",
    width: "العرض",
    height: "الارتفاع",
    quality: "الجودة",
    qualityFast: "سريعة",
    qualityBalanced: "متوازنة",
    qualityHigh: "عالية",
    generate: "توليد",
    generating: "جارٍ التوليد…",
    imagegenDisabled: "توليد الصور غير مفعّل",
    imagegenDisabledHint: "اضبط عنوان خادم Stable Diffusion (AUTOMATIC1111) الذي يعمل على جهازك من صفحة الإعدادات، ثم أعد المحاولة. لا نحاكي التوليد بصور وهمية.",
    imagegenHistory: "الصور المولّدة",
    settingsTitle: "الإعدادات",
    language: "اللغة",
    appearance: "المظهر",
    themeDark: "داكن",
    themeLight: "فاتح",
    accentColor: "لون التمييز",
    performance: "الأداء",
    contextLength: "طول السياق (Context Length)",
    cpuThreads: "خيوط المعالج (CPU Threads)",
    gpuNote: "تُستخدم هذه الإعدادات عند الاتصال بالسيرفر الخاص (llama.cpp).",
    serverSettings: "السيرفر الخاص",
    serverUrl: "عنوان السيرفر",
    serverUrlPlaceholder: "http://192.168.1.5:8080",
    serverKey: "مفتاح API (اختياري)",
    serverModel: "معرّف النموذج (اختياري)",
    runMode: "وضع التشغيل",
    modeLocal: "المحرك المحلي (الافتراضي)",
    modeRemote: "السيرفر الخاص",
    checkConnection: "فحص الاتصال",
    connected: "متصل",
    connectionFailed: "فشل الاتصال",
    imagegenEndpoint: "عنوان خادم توليد الصور (A1111)",
    storage: "التخزين",
    storageUsed: "المساحة المستخدمة",
    conversationsCount: "المحادثات",
    messagesCount: "الرسائل",
    filesCount: "الملفات",
    exportData: "تصدير البيانات (JSON)",
    deleteAllData: "حذف كل بيانات التطبيق",
    deleteAllConfirm: "سيتم حذف كل المحادثات والملفات والنماذج نهائياً. متابعة؟",
    about: "حول التطبيق",
    version: "الإصدار",
    engine: "المحرك",
    activeSkills: "المهارات المفعّلة تُحقن تلقائياً في سياق المحادثة.",
    deleteAll: "حذف الكل",
    downloadSpeed: "السرعة",
  },
  en: {
    appName: "One AI",
    tagline: "Your AI assistant — runs locally",
    navChat: "Chat",
    navModels: "Models",
    navSkills: "Skills",
    navFiles: "Files",
    navImageGen: "Image Generation",
    navSettings: "Settings",
    newChat: "New chat",
    noConversations: "No conversations yet",
    typeMessage: "Type your message…",
    send: "Send",
    stop: "Stop",
    copy: "Copy",
    copied: "Copied",
    regenerate: "Regenerate",
    thinking: "Thinking…",
    rename: "Rename",
    delete: "Delete",
    pin: "Pin",
    unpin: "Unpin",
    confirmDelete: "Delete this conversation permanently?",
    attach: "Attach file",
    attachImagesNote: "Attach PDF, TXT or images (PNG/JPG/WebP)",
    welcomeTitle: "How can I help you today?",
    welcomeSub: "Conversations stored locally — your data never leaves your device",
    errorGeneric: "Something went wrong. Try again.",
    engineLocal: "Local engine",
    engineRemote: "Private server",
    disconnected: "Disconnected",
    modelsTitle: "Models",
    modelsSub: "Open-source GGUF models — downloaded and managed locally",
    levelBeta: "Beta — lightweight (~0.5GB)",
    levelAlpha: "Alpha — balanced (1–2GB)",
    levelGamma: "Gamma — most powerful (4–5GB)",
    download: "Download",
    downloading: "Downloading…",
    pause: "Pause",
    resume: "Resume",
    cancel: "Cancel",
    deleteModel: "Delete model",
    installed: "Installed",
    notInstalled: "Not installed",
    paused: "Paused",
    verifying: "Verifying…",
    downloadError: "Download error",
    modelSize: "Size",
    modelStatus: "Status",
    modelProgress: "Progress",
    downloadHint: "After downloading, run the model through a private llama.cpp server (see Settings).",
    skillsTitle: "Skills",
    skillsSub: "Extend the assistant with custom skills and knowledge",
    addSkill: "New skill",
    skillName: "Name",
    skillNameAr: "Name (Arabic)",
    skillDesc: "Description",
    skillDescAr: "Description (Arabic)",
    skillPrompt: "System instructions for the skill",
    save: "Save",
    cancelAction: "Cancel",
    enabled: "Enabled",
    disabled: "Disabled",
    builtin: "Built-in",
    custom: "Custom",
    knowledge: "Knowledge files",
    uploadKnowledge: "Upload knowledge file (TXT/MD/PDF)",
    noKnowledge: "No knowledge files",
    deleteSkillConfirm: "Delete this skill and all its knowledge?",
    filesTitle: "Files",
    filesSub: "Your uploaded documents — analyzed locally and usable in chats",
    uploadFile: "Upload file",
    noFiles: "No files yet",
    fileKindPdf: "PDF",
    fileKindText: "Text",
    fileKindImage: "Image",
    summarizeFile: "Summarize this file",
    askFile: "Ask about this file",
    imagegenTitle: "Image Generation",
    imagegenSub: "Generate images with a local AI model",
    prompt: "Text prompt",
    promptPlaceholder: "A sunset over snowy mountains…",
    negativePrompt: "Negative prompt (optional)",
    width: "Width",
    height: "Height",
    quality: "Quality",
    qualityFast: "Fast",
    qualityBalanced: "Balanced",
    qualityHigh: "High",
    generate: "Generate",
    generating: "Generating…",
    imagegenDisabled: "Image generation is disabled",
    imagegenDisabledHint: "Set your local Stable Diffusion (AUTOMATIC1111) server address in Settings, then try again. We never fake generation with placeholder images.",
    imagegenHistory: "Generated images",
    settingsTitle: "Settings",
    language: "Language",
    appearance: "Appearance",
    themeDark: "Dark",
    themeLight: "Light",
    accentColor: "Accent color",
    performance: "Performance",
    contextLength: "Context length",
    cpuThreads: "CPU threads",
    gpuNote: "These settings apply when connected to a private llama.cpp server.",
    serverSettings: "Private server",
    serverUrl: "Server URL",
    serverUrlPlaceholder: "http://192.168.1.5:8080",
    serverKey: "API key (optional)",
    serverModel: "Model id (optional)",
    runMode: "Run mode",
    modeLocal: "Local engine (default)",
    modeRemote: "Private server",
    checkConnection: "Check connection",
    connected: "Connected",
    connectionFailed: "Connection failed",
    imagegenEndpoint: "Image generation server (A1111)",
    storage: "Storage",
    storageUsed: "Storage used",
    conversationsCount: "Conversations",
    messagesCount: "Messages",
    filesCount: "Files",
    exportData: "Export data (JSON)",
    deleteAllData: "Delete all app data",
    deleteAllConfirm: "All conversations, files and models will be permanently deleted. Continue?",
    about: "About",
    version: "Version",
    engine: "Engine",
    activeSkills: "Enabled skills are injected into the chat context automatically.",
    deleteAll: "Delete all",
    downloadSpeed: "Speed",
  },
} as const;

export type TranslationKey = keyof (typeof dict)["ar"];

interface I18nCtx {
  lang: Lang;
  t: (key: TranslationKey) => string;
  setLang: (l: Lang) => void;
  ready: boolean;
}

const Ctx = createContext<I18nCtx>({
  lang: "ar",
  t: (k) => k,
  setLang: () => undefined,
  ready: false,
});

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("ar");
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let mounted = true;
    fetch("/api/trpc/settings.getAll")
      .then((r) => r.json())
      .then((j) => {
        if (!mounted) return;
        const saved = j?.result?.data?.json?.language as Lang | undefined;
        applyLang(saved === "en" ? "en" : "ar");
        setReady(true);
      })
      .catch(() => {
        const saved = (localStorage.getItem("oneai-lang") as Lang) || "ar";
        applyLang(saved);
        setReady(true);
      });
    return () => {
      mounted = false;
    };
  }, []);

  function applyLang(l: Lang) {
    setLangState(l);
    document.documentElement.lang = l;
    document.documentElement.dir = l === "ar" ? "rtl" : "ltr";
    localStorage.setItem("oneai-lang", l);
  }

  function setLang(l: Lang) {
    applyLang(l);
    void fetch(`/api/trpc/settings.set`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ json: { key: "language", value: l } }),
    }).catch(() => undefined);
  }

  const t = (key: TranslationKey) => dict[lang][key] ?? key;
  return <Ctx.Provider value={{ lang, t, setLang, ready }}>{children}</Ctx.Provider>;
}

export function useI18n() {
  return useContext(Ctx);
}
