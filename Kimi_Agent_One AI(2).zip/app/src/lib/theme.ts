/**
 * تطبيق المظهر (داكن/فاتح) ولون التمييز على documentElement.
 * الألوان HSL لتتوافق مع متغيرات Tailgate/shadcn.
 */
export type Accent = "violet" | "teal" | "amber" | "rose";

export const ACCENTS: Record<Accent, { light: string; dark: string; label: string; labelAr: string }> = {
  violet: { light: "262 83% 58%", dark: "263 90% 72%", label: "Violet", labelAr: "بنفسجي" },
  teal: { light: "175 84% 32%", dark: "172 72% 55%", label: "Teal", labelAr: "فيروزي" },
  amber: { light: "32 95% 44%", dark: "38 92% 58%", label: "Amber", labelAr: "عنبري" },
  rose: { light: "347 77% 50%", dark: "348 95% 68%", label: "Rose", labelAr: "وردي" },
};

export function applyTheme(theme: "dark" | "light", accent: Accent) {
  const root = document.documentElement;
  root.classList.toggle("dark", theme === "dark");
  root.classList.remove("accent-violet", "accent-teal", "accent-amber", "accent-rose");
  root.classList.add(`accent-${accent}`);
  const a = ACCENTS[accent];
  root.style.setProperty("--primary", theme === "dark" ? a.dark : a.light);
  root.style.setProperty("--ring", theme === "dark" ? a.dark : a.light);
  root.style.setProperty("--sidebar-primary", theme === "dark" ? a.dark : a.light);
}

/** يقرأ الإعدادات من الخادم ويطبقها — يُستدعى عند الإقلاع */
export async function bootTheme() {
  const fallback = () => {
    const theme = (localStorage.getItem("oneai-theme") as "dark" | "light") || "dark";
    const accent = (localStorage.getItem("oneai-accent") as Accent) || "violet";
    applyTheme(theme, accent);
  };
  try {
    const res = await fetch("/api/trpc/settings.getAll");
    const j = await res.json();
    const s = j?.result?.data?.json as Record<string, string> | undefined;
    if (!s) return fallback();
    const theme = s.theme === "light" ? "light" : "dark";
    const accent = (s.accent as Accent) || "violet";
    applyTheme(theme, accent);
  } catch {
    fallback();
  }
}
