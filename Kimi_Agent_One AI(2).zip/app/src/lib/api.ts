/**
 * أدوات الاتصال بالخادم المحلي + قارئ SSE.
 */
export async function jfetch<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, init);
  if (!res.ok) {
    let msg = `HTTP ${res.status}`;
    try {
      const j = await res.json();
      if (j?.error) msg = j.error;
    } catch {
      /* تجاهل */
    }
    throw new Error(msg);
  }
  return res.json() as Promise<T>;
}

export interface SSEHandlers {
  onEvent: (obj: Record<string, unknown>) => void | Promise<void>;
  onError?: (err: Error) => void;
}

/** يقرأ بث SSE حتى النهاية — يرمي خطأ عند انقطاع البث غير المتوقع */
export async function readSSE(res: Response, handlers: SSEHandlers): Promise<void> {
  if (!res.ok || !res.body) throw new Error(`HTTP ${res.status}`);
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const parts = buffer.split("\n\n");
      buffer = parts.pop() ?? "";
      for (const part of parts) {
        const line = part.split("\n").find((l) => l.startsWith("data:"));
        if (!line) continue;
        try {
          await handlers.onEvent(JSON.parse(line.slice(5).trim()));
        } catch (err) {
          handlers.onError?.(err instanceof Error ? err : new Error(String(err)));
        }
      }
    }
  } finally {
    reader.cancel().catch(() => undefined);
  }
}

export function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 ** 2) return `${(n / 1024).toFixed(1)} KB`;
  if (n < 1024 ** 3) return `${(n / 1024 ** 2).toFixed(1)} MB`;
  return `${(n / 1024 ** 3).toFixed(2)} GB`;
}
