/**
 * الهيكل العام — قائمة جانبية (ثابتة على سطح المكتب، منزلقة على الجوال).
 */
import { useState, type ReactNode } from "react";
import { NavLink, useNavigate } from "react-router";
import { Menu, MessageSquare, Boxes, Sparkles, FolderOpen, ImageIcon, Settings as SettingsIcon, Plus, X } from "lucide-react";
import { Logo } from "./Logo";
import { useI18n } from "@/lib/i18n";

const NAV = [
  { to: "/chat", key: "navChat" as const, icon: MessageSquare },
  { to: "/models", key: "navModels" as const, icon: Boxes },
  { to: "/skills", key: "navSkills" as const, icon: Sparkles },
  { to: "/files", key: "navFiles" as const, icon: FolderOpen },
  { to: "/imagegen", key: "navImageGen" as const, icon: ImageIcon },
  { to: "/settings", key: "navSettings" as const, icon: SettingsIcon },
];

export function AppShell({ children, actions }: { children: ReactNode; actions?: ReactNode }) {
  const { t } = useI18n();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const sidebar = (
    <div className="flex flex-col h-full bg-sidebar text-sidebar-foreground border-e border-sidebar-border">
      <div className="flex items-center gap-2.5 px-4 h-16 border-b border-sidebar-border">
        <Logo size={30} />
        <div className="leading-tight">
          <div className="font-bold text-[15px]">{t("appName")}</div>
          <div className="text-[11px] opacity-60">{t("tagline")}</div>
        </div>
        <button
          className="ms-auto md:hidden p-2 rounded-lg hover:bg-sidebar-accent"
          onClick={() => setOpen(false)}
          aria-label="close"
        >
          <X size={18} />
        </button>
      </div>
      <nav className="flex-1 overflow-y-auto p-2 space-y-0.5">
        {NAV.map(({ to, key, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            onClick={() => setOpen(false)}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors min-h-[44px] ${
                isActive ? "bg-sidebar-primary text-sidebar-primary-foreground" : "hover:bg-sidebar-accent"
              }`
            }
          >
            <Icon size={18} />
            {t(key)}
          </NavLink>
        ))}
      </nav>
      <div className="p-3 border-t border-sidebar-border">
        <button
          onClick={() => {
            navigate("/chat");
            setOpen(false);
          }}
          className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl text-sm font-semibold bg-sidebar-primary text-sidebar-primary-foreground min-h-[44px]"
        >
          <Plus size={16} />
          {t("newChat")}
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex h-dvh overflow-hidden bg-background text-foreground">
      {/* سطح المكتب */}
      <aside className="hidden md:block w-64 shrink-0">{sidebar}</aside>
      {/* الجوال */}
      {open && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 start-0 w-72 max-w-[85vw]">{sidebar}</aside>
        </div>
      )}
      <main className="flex-1 flex flex-col min-w-0">
        <header className="md:hidden flex items-center gap-2 px-3 h-14 border-b border-border shrink-0">
          <button className="p-2.5 rounded-lg hover:bg-accent min-h-[44px] min-w-[44px] flex items-center justify-center" onClick={() => setOpen(true)} aria-label="menu">
            <Menu size={20} />
          </button>
          <Logo size={24} />
          <span className="font-bold">{t("appName")}</span>
          {actions}
        </header>
        <div className="hidden md:flex items-center gap-2 px-6 h-14 border-b border-border shrink-0">{actions}</div>
        {children}
      </main>
    </div>
  );
}
