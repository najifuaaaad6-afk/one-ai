/**
 * شعار One AI الأصلي — حرف O متوهج يحيط بشرارة ذكاء.
 */
export function Logo({ size = 32 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none" aria-hidden="true">
      <defs>
        <linearGradient id="oneai-g" x1="4" y1="4" x2="44" y2="44">
          <stop offset="0%" stopColor="hsl(var(--primary))" />
          <stop offset="100%" stopColor="hsl(var(--primary) / 0.55)" />
        </linearGradient>
      </defs>
      <circle cx="24" cy="24" r="19" stroke="url(#oneai-g)" strokeWidth="3.5" strokeLinecap="round" strokeDasharray="96 24" transform="rotate(-45 24 24)" />
      <path
        d="M24 14 L26.2 21.2 L33.5 23.4 L26.2 25.6 L24 32.8 L21.8 25.6 L14.5 23.4 L21.8 21.2 Z"
        fill="hsl(var(--primary))"
      />
    </svg>
  );
}
