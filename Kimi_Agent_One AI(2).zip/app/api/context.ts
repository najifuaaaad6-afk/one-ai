import type { FetchCreateContextFnOptions } from "@trpc/server/adapters/fetch";

/** تطبيق محلي أحادي المستخدم — لا مصادقة، السياق يحمل الطلب فقط */
export type TrpcContext = {
  req: Request;
  resHeaders: Headers;
};

export async function createContext(opts: FetchCreateContextFnOptions): Promise<TrpcContext> {
  return { req: opts.req, resHeaders: opts.resHeaders };
}
