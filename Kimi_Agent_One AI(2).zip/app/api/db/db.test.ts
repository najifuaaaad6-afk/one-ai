/**
 * اختبارات تكامل قاعدة البيانات — SQLite في ذاكرة مؤقتة لكل اختبار.
 */
import { beforeEach, describe, it, expect } from "vitest";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

let dir: string;
process.env.ONEAI_DATA_DIR = (dir = fs.mkdtempSync(path.join(os.tmpdir(), "oneai-test-")));

const { all, get, run, saveNow, seedIfEmpty, buildSystemContext } = await import("./index")
  .then(async (db) => ({ ...db, buildSystemContext: (await import("../lib/skills")).buildSystemContext }));

beforeEach(async () => {
  const files = fs.readdirSync(dir);
  for (const f of files) fs.rmSync(path.join(dir, f), { force: true });
  // إعادة تعيين الوحدة لقاعدة جديدة
  const mod = await import("./index");
  await mod.closeDb();
  fs.rmSync(path.join(dir, "oneai.db"), { force: true });
  await mod.getDb();
});

describe("SQLite — العمليات الأساسية", () => {
  it("تهيئة المخطط والبذور الافتراضية", async () => {
    await seedIfEmpty();
    const skills = await all("SELECT * FROM skills WHERE builtin=1");
    expect(skills.length).toBe(7);
    const s = await get("SELECT value FROM settings WHERE key='language'");
    expect(s?.value).toBe("ar");
  });

  it("محادثة مع رسائل وحذف مت串联", async () => {
    await run("INSERT INTO conversations(id,title,created_at,updated_at) VALUES('c1','اختبار',1,1)");
    await run("INSERT INTO messages(id,conversation_id,role,content,status,attachments,created_at) VALUES('m1','c1','user','مرحبا','complete','[]',2)");
    await run("INSERT INTO messages(id,conversation_id,role,content,status,attachments,created_at) VALUES('m2','c1','assistant','أهلاً','complete','[]',3)");
    const msgs = await all("SELECT * FROM messages WHERE conversation_id='c1' ORDER BY created_at");
    expect(msgs.length).toBe(2);
    await run("DELETE FROM conversations WHERE id='c1'");
    const after = await all("SELECT * FROM messages WHERE conversation_id='c1'");
    expect(after.length).toBe(0); // CASCADE
  });

  it("الحفظ على القرص وإعادة التحميل", async () => {
    await run("INSERT INTO conversations(id,title,created_at,updated_at) VALUES('c2','دائمة',1,1)");
    await saveNow();
    expect(fs.existsSync(path.join(dir, "oneai.db"))).toBe(true);
    const size = fs.statSync(path.join(dir, "oneai.db")).size;
    expect(size).toBeGreaterThan(0);
  });

  it("معرفة المهارات تدخل سياق المحادثة عند الصلة", async () => {
    await seedIfEmpty();
    await run("INSERT INTO skill_knowledge(id,skill_id,filename,content,created_at) VALUES('k1','study','علوم.md','النظام الشمسي يتكون من الشمس وثمانية كواكب منها المريخ والأرض',1)");
    const ctx = await buildSystemContext("ما هي كواكب النظام الشمسي");
    expect(ctx).toContain("النظام الشمسي");
    const ctx2 = await buildSystemContext("ما رأيك في الطقس");
    expect(ctx2).not.toContain("النظام الشمسي");
  });
});
