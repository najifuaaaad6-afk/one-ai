/**
 * One AI — طبقة البيانات المحلية (SQLite عبر sql.js)
 *
 * قاعدة بيانات SQLite حقيقية تُحفظ في ملف data/oneai.db على القرص.
 * sql.js يشغّل محرك SQLite فعلي (WASM) داخل العملية، ونصدّر الصورة إلى
 * الملف بعد كل تعديل (مع debounce) وعند الإيقاف.
 */
import fs from "node:fs";
import path from "node:path";
import { log } from "../lib/logger";
import { initSqlJsInline } from "../lib/shims";

export type SqlJsDatabase = import("sql.js").Database;

const DATA_DIR = process.env.ONEAI_DATA_DIR || path.join(process.cwd(), "data");
const DB_FILE = path.join(DATA_DIR, "oneai.db");

let dbPromise: Promise<SqlJsDatabase> | null = null;
let saveTimer: ReturnType<typeof setTimeout> | null = null;

export const SCHEMA = `
CREATE TABLE IF NOT EXISTS conversations (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL DEFAULT '',
  engine TEXT DEFAULT 'local',
  model TEXT DEFAULT '',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  pinned INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,
  conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  role TEXT NOT NULL,
  content TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'complete',
  attachments TEXT NOT NULL DEFAULT '[]',
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_conv ON messages(conversation_id, created_at);
CREATE TABLE IF NOT EXISTS skills (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  name_ar TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL DEFAULT '',
  description_ar TEXT NOT NULL DEFAULT '',
  prompt TEXT NOT NULL DEFAULT '',
  builtin INTEGER NOT NULL DEFAULT 0,
  enabled INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS skill_knowledge (
  id TEXT PRIMARY KEY,
  skill_id TEXT NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
  filename TEXT NOT NULL,
  content TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_knowledge_skill ON skill_knowledge(skill_id);
CREATE TABLE IF NOT EXISTS files (
  id TEXT PRIMARY KEY,
  filename TEXT NOT NULL,
  mime TEXT NOT NULL,
  size INTEGER NOT NULL,
  kind TEXT NOT NULL,
  text TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS models (
  id TEXT PRIMARY KEY,
  level TEXT NOT NULL,
  name TEXT NOT NULL,
  repo TEXT NOT NULL,
  filename TEXT NOT NULL,
  url TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  sha256 TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'none',
  progress_bytes INTEGER NOT NULL DEFAULT 0,
  path TEXT NOT NULL DEFAULT '',
  error TEXT NOT NULL DEFAULT '',
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
`;

async function createDatabase(): Promise<SqlJsDatabase> {
  // النسخة المضمّنة تحمل wasm داخل JS — لا ملفات خارجية مطلوبة
  const SQL = await initSqlJsInline();
  fs.mkdirSync(DATA_DIR, { recursive: true });
  let db: SqlJsDatabase;
  if (fs.existsSync(DB_FILE)) {
    const bytes = fs.readFileSync(DB_FILE);
    db = new SQL.Database(bytes);
    log.info("sqlite loaded", { file: DB_FILE, bytes: bytes.length });
  } else {
    db = new SQL.Database();
    log.info("sqlite created new database", { file: DB_FILE });
  }
  db.run("PRAGMA foreign_keys = ON;");
  db.exec(SCHEMA);
  return db;
}

/** الوصول المتزامن بعد التهيئة — كل الاستعلامات تمر هنا */
export async function getDb(): Promise<SqlJsDatabase> {
  if (!dbPromise) dbPromise = createDatabase();
  return dbPromise;
}

/** استعلام يعيد صفوفاً كأغراض */
export async function all<T = Record<string, string | number | null>>(sql: string, params: (string | number | null)[] = []): Promise<T[]> {
  const db = await getDb();
  const stmt = db.prepare(sql);
  try {
    stmt.bind(params as never);
    const out: T[] = [];
    while (stmt.step()) out.push(stmt.getAsObject() as T);
    return out;
  } finally {
    stmt.free();
    scheduleSave();
  }
}

export async function get<T = Record<string, string | number | null>>(sql: string, params: (string | number | null)[] = []): Promise<T | null> {
  const rows = await all<T>(sql, params);
  return rows[0] ?? null;
}

export async function run(sql: string, params: (string | number | null)[] = []): Promise<void> {
  const db = await getDb();
  db.run(sql, params as never);
  scheduleSave();
}

function scheduleSave(): void {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    void saveNow();
  }, 400);
}

/** تصدير صورة قاعدة البيانات إلى القرص فوراً */
export async function saveNow(): Promise<void> {
  const db = await getDb();
  const data = db.export();
  const tmp = DB_FILE + ".tmp";
  fs.writeFileSync(tmp, Buffer.from(data));
  fs.renameSync(tmp, DB_FILE);
}

export async function closeDb(): Promise<void> {
  if (saveTimer) {
    clearTimeout(saveTimer);
    saveTimer = null;
  }
  if (dbPromise) {
    const db = await dbPromise;
    const data = db.export();
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(DB_FILE, Buffer.from(data));
    db.close();
    dbPromise = null;
  }
}

export function dbFilePath(): string {
  return DB_FILE;
}
export function dataDir(): string {
  return DATA_DIR;
}

process.on("SIGTERM", () => void closeDb());
process.on("SIGINT", () => void closeDb());

/** تهيئة إعدادات افتراضية ومهارات مدمجة عند أول تشغيل */
export async function seedIfEmpty(): Promise<void> {
  const s = await get<{ n: number }>("SELECT COUNT(*) AS n FROM skills");
  if (s && Number(s.n) > 0) return;
  const now = Date.now();
  const builtins: [string, string, string, string, string, string][] = [
    ["programming", "Programming", "البرمجة", "Code help, debugging, architecture", "مساعدة في البرمجة وتصحيح الأخطاء وهندسة الأنظمة", "You are an expert software engineer. Answer with clear, correct, production-quality code. Always explain key decisions briefly."],
    ["math", "Math", "الرياضيات", "Step-by-step math problem solving", "حل المسائل الرياضية خطوة بخطوة", "You are a careful mathematician. Solve problems step by step, show your reasoning, and state assumptions explicitly."],
    ["translation", "Translation", "الترجمة", "Accurate translation between languages", "ترجمة دقيقة بين العربية والإنجليزية ولغات أخرى", "You are a professional translator. Preserve tone, terminology and meaning. If the source is ambiguous, offer alternatives."],
    ["writing", "Writing", "الكتابة", "Writing, editing and style improvement", "الكتابة وتحرير النصوص وتحسين الأسلوب", "You are an editor and writer. Improve clarity, structure and style while keeping the author's voice."],
    ["study", "Study Help", "المساعدة في الدراسة", "Explain concepts for learning", "شرح المفاهيم بطريقة مبسطة للتعلم", "You are a patient teacher. Explain concepts simply, use examples, and check understanding with short questions."],
    ["file-analysis", "File Analysis", "تحليل الملفات", "Analyze uploaded documents", "تحليل المستندات المرفوعة وتلخيصها", "You analyze documents provided by the user. Summarize accurately and answer questions grounded in the file content."],
    ["image-analysis", "Image Analysis", "تحليل الصور", "Understand and describe images", "فهم محتوى الصور ووصفها", "You describe and analyze images provided by the user. Be precise about what is visible and avoid speculation."],
  ];
  for (const [id, name, nameAr, desc, descAr, prompt] of builtins) {
    await run(
      "INSERT OR IGNORE INTO skills(id,name,name_ar,description,description_ar,prompt,builtin,enabled,created_at) VALUES(?,?,?,?,?,?,?,1,?)",
      [id, name, nameAr, desc, descAr, prompt, 1, now],
    );
  }
  const defaults: [string, string][] = [
    ["language", "ar"],
    ["theme", "dark"],
    ["accent", "violet"],
    ["context_length", "4096"],
    ["threads", String(Math.max(2, Math.min(8, (globalThis as never as { process?: { availableParallelism?: () => number } }).process?.availableParallelism?.() ?? 4)))],
    ["engine", "local"],
    ["remote_url", ""],
    ["remote_key", ""],
    ["imagegen_endpoint", ""],
  ];
  for (const [k, v] of defaults) {
    await run("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", [k, v]);
  }
}
