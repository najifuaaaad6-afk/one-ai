/**
 * السيرفر الخاص — ربط اختياري بخادم llama.cpp يشغّله المستخدم على جهازه.
 * اتصال مباشر من المتصفح/الهاتف إلى جهازه (بلا وسيط). يتحقق الحالة بجلب /v1/models.
 */
import { Hono } from "hono";
import { z } from "zod";
import { getSetting, setSetting } from "../lib/settings";

export const serverRoutes = new Hono();

serverRoutes.get("/config", async (c) => {
  const [url, key, model] = await Promise.all([getSetting("remote_url"), getSetting("remote_key"), getSetting("remote_model")]);
  return c.json({ url, hasKey: key.length > 0, model, connected: false });
});

const configSchema = z.object({
  url: z.string().max(300).default(""),
  key: z.string().max(300).default(""),
  model: z.string().max(120).default(""),
});

serverRoutes.post("/config", async (c) => {
  const body = configSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!body.success) return c.json({ error: "بيانات غير صالحة" }, 400);
  await setSetting("remote_url", body.data.url.trim());
  await setSetting("remote_key", body.data.key.trim());
  await setSetting("remote_model", body.data.model.trim());
  return c.json({ ok: true });
});

serverRoutes.get("/check", async (c) => {
  const url = (await getSetting("remote_url")).trim();
  if (!url) return c.json({ ok: false, message: "لم يُضبط عنوان السيرفر" });
  try {
    const res = await fetch(`${url.replace(/\/+$/, "")}/v1/models`, {
      headers: { Authorization: `Bearer ${await getSetting("remote_key")}` },
      signal: AbortSignal.timeout(6000),
    });
    if (!res.ok) return c.json({ ok: false, message: `السيرفر استجاب بخطأ ${res.status}` });
    const data = (await res.json()) as { data?: { id: string }[] };
    const models = (data.data ?? []).map((m) => m.id).slice(0, 10);
    return c.json({ ok: true, models });
  } catch {
    return c.json({ ok: false, message: "تعذّر الوصول إلى السيرفر — تحقق من العنوان والشبكة المحلية" });
  }
});
