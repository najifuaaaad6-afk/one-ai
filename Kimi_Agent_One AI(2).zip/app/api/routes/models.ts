/**
 * النماذج — الكتالوج، حالة التنزيل، التحكم (تنزيل/إيقاف/استئناف/إلغاء/حذف).
 */
import fs from "node:fs";
import { Hono } from "hono";
import { listModels, startDownload, pauseDownload, resumeDownload, cancelDownload, deleteModel, clampPercent } from "../lib/downloads";
import { dataDir } from "../db";

export const modelsRoutes = new Hono();

modelsRoutes.get("/", async (c) => {
  const models = await listModels();
  const withProgress = models.map((m) => {
    let progress = m.progress_bytes;
    // مزامنة التقدم مع حجم الملف الفعلي على القرص أثناء الاستئناف
    if (m.path && fs.existsSync(m.path) && m.status !== "installed") {
      progress = Math.min(fs.statSync(m.path).size, m.size_bytes);
    }
    return {
      ...m,
      progress_bytes: progress,
      percent: clampPercent(progress, m.size_bytes),
      error: m.error,
    };
  });
  return c.json(withProgress);
});

modelsRoutes.post("/:id/download", async (c) => {
  const r = await startDownload(c.req.param("id"));
  if (!r.ok) return c.json({ error: r.error }, 400);
  return c.json({ ok: true });
});

modelsRoutes.post("/:id/pause", async (c) => {
  await pauseDownload(c.req.param("id"));
  return c.json({ ok: true });
});

modelsRoutes.post("/:id/resume", async (c) => {
  const r = await resumeDownload(c.req.param("id"));
  if (!r.ok) return c.json({ error: r.error }, 400);
  return c.json({ ok: true });
});

modelsRoutes.post("/:id/cancel", async (c) => {
  await cancelDownload(c.req.param("id"));
  return c.json({ ok: true });
});

modelsRoutes.delete("/:id", async (c) => {
  await deleteModel(c.req.param("id"));
  return c.json({ ok: true });
});

modelsRoutes.get("/storage", async (c) => {
  const dir = dataDir();
  const modelsDir = `${dir}/models`;
  let modelsBytes = 0;
  if (fs.existsSync(modelsDir)) {
    for (const f of fs.readdirSync(modelsDir)) modelsBytes += fs.statSync(`${modelsDir}/${f}`).size;
  }
  return c.json({ modelsBytes });
});
