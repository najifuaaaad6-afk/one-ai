/**
 * النظام — التخزين، التصدير، المسح، المعلومات.
 */
import fs from "node:fs";
import path from "node:path";
import { Hono } from "hono";
import { all, run, dataDir, dbFilePath, saveNow } from "../db";
import { engineInfo } from "../engine";

export const systemRoutes = new Hono();

function dirSize(dir: string): number {
  if (!fs.existsSync(dir)) return 0;
  let total = 0;
  for (const f of fs.readdirSync(dir)) {
    const p = path.join(dir, f);
    try {
      const st = fs.statSync(p);
      total += st.isDirectory() ? dirSize(p) : st.size;
    } catch {
      /* تجاهل */
    }
  }
  return total;
}

systemRoutes.get("/storage", async (c) => {
  const db = fs.existsSync(dbFilePath()) ? fs.statSync(dbFilePath()).size : 0;
  const files = dirSize(path.join(dataDir(), "files"));
  const models = dirSize(path.join(dataDir(), "models"));
  const conversations = await all<{ n: number }>("SELECT COUNT(*) AS n FROM conversations");
  const messages = await all<{ n: number }>("SELECT COUNT(*) AS n FROM messages");
  const fileCount = await all<{ n: number }>("SELECT COUNT(*) AS n FROM files");
  return c.json({
    dbBytes: db,
    filesBytes: files,
    modelsBytes: models,
    totalBytes: db + files + models,
    conversations: Number(conversations[0]?.n ?? 0),
    messagesCount: Number(messages[0]?.n ?? 0),
    filesCount: Number(fileCount[0]?.n ?? 0),
  });
});

systemRoutes.get("/info", async (c) => {
  return c.json({
    name: "One AI",
    version: "0.1.0",
    engine: await engineInfo(),
  });
});

systemRoutes.post("/export", async (c) => {
  await saveNow();
  const conversations = await all("SELECT * FROM conversations ORDER BY updated_at DESC");
  const messages = await all("SELECT * FROM messages ORDER BY created_at ASC");
  const settings = await all("SELECT * FROM settings");
  return c.json({ exportedAt: new Date().toISOString(), conversations, messages, settings });
});

systemRoutes.post("/wipe", async (c) => {
  const dir = dataDir();
  await saveNow();
  for (const sub of ["files", "models"]) {
    const p = path.join(dir, sub);
    if (fs.existsSync(p)) fs.rmSync(p, { recursive: true, force: true });
  }
  await run("DELETE FROM messages");
  await run("DELETE FROM conversations");
  await run("DELETE FROM files");
  await run("DELETE FROM skill_knowledge");
  await run("DELETE FROM skills WHERE builtin = 0");
  await run("UPDATE skills SET enabled = 0 WHERE builtin = 0");
  await run("UPDATE models SET status='none', progress_bytes=0, path='', error=''");
  return c.json({ ok: true });
});
