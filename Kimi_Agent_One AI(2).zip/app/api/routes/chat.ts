/**
 * محادثة — إرسال/بث/إيقاف/إعادة توليد عبر SSE.
 * البيانات تُحفظ في SQLite فوراً، والتوليد يبث رموزاً حقيقية من المحرك.
 */
import { Hono } from "hono";
import type { Context } from "hono";
import { stream } from "hono/streaming";
import { z } from "zod";
import { all, get, run } from "../db";
import { chat, engineInfo } from "../engine";
import { buildSystemContext } from "../lib/skills";
import { getSetting } from "../lib/settings";
import { log } from "../lib/logger";
import type { ChatMessage } from "../engine";

export const chatRoutes = new Hono();

const sendSchema = z.object({
  conversationId: z.string().optional(),
  content: z.string().min(1).max(20000),
  fileIds: z.array(z.string()).optional(),
});

const aborts = new Map<string, AbortController>();

function uid(): string {
  return crypto.randomUUID();
}

async function fileToPart(fileId: string): Promise<{ text?: string; image?: string } | null> {
  const f = await get<{ mime: string; kind: string; text: string }>("SELECT mime,kind,text FROM files WHERE id=?", [fileId]);
  if (!f) return null;
  if (f.kind === "image") {
    // نخدم الصورة كرابط عام داخل التطبيق — النموذج يجلبها عبر الرؤية
    return { image: `/api/files/${fileId}/raw` };
  }
  return { text: f.text || "" };
}

/** توليد عنوان المحادثة من أول رسالة عبر المحرك نفسه */
async function makeTitle(content: string): Promise<string> {
  try {
    const { generateText } = await import("ai");
    const { createOpenAICompatible } = await import("@ai-sdk/openai-compatible");
    const { listModels } = await import("../ai/ai-client");
    const baseURL = process.env.KIMI_AGENTGW_BASE_URL;
    const apiKey = process.env.KIMI_AGENTGW_API_KEY;
    if (!baseURL || !apiKey) return content.slice(0, 40);
    const gateway = createOpenAICompatible({ name: "kimi-gw", baseURL, apiKey });
    const list = await listModels();
    const result = await generateText({
      model: gateway(list.defaultModelId),
      messages: [
        { role: "system", content: "اكتب عنواناً قصيراً جداً (5 كلمات كحد أقصى) لمحادثة تبدأ بهذه الرسالة. أعد العنوان فقط دون أي شيء آخر." },
        { role: "user", content: content.slice(0, 500) },
      ],
      providerOptions: { "kimi-gw": { max_completion_tokens: 80 } },
    });
    return result.text.trim().slice(0, 60) || content.slice(0, 40);
  } catch {
    return content.slice(0, 40);
  }
}

async function persistMessage(convId: string, role: string, content: string, status = "complete", attachments = "[]") {
  const id = uid();
  await run("INSERT INTO messages(id,conversation_id,role,content,status,attachments,created_at) VALUES(?,?,?,?,?,?,?)", [
    id, convId, role, content, status, attachments, Date.now(),
  ]);
  return id;
}

chatRoutes.post("/send", async (c) => {
  const body = sendSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!body.success) return c.json({ error: "طلب غير صالح" }, 400);
  const { content, fileIds = [] } = body.data;

  let convId = body.data.conversationId;
  if (!convId) {
    convId = uid();
    const newConvId = convId;
    await run("INSERT INTO conversations(id,title,created_at,updated_at) VALUES(?,?,?,?)", [convId, "", Date.now(), Date.now()]);
    await persistMessage(convId, "user", content, "complete", JSON.stringify(fileIds));
    void makeTitle(content).then(async (title) => {
      await run("UPDATE conversations SET title=? WHERE id=?", [title, newConvId]);
    });
  } else {
    const conv = await get("SELECT id FROM conversations WHERE id=?", [convId]);
    if (!conv) return c.json({ error: "المحادثة غير موجودة" }, 404);
    await persistMessage(convId, "user", content, "complete", JSON.stringify(fileIds));
  }
  await run("UPDATE conversations SET updated_at=? WHERE id=?", [Date.now(), convId]);

  const assistantId = await persistMessage(convId, "assistant", "", "streaming");
  const controller = new AbortController();
  aborts.set(assistantId, controller);

  return streamAnswer(c, convId, assistantId, content, fileIds, controller);
});

chatRoutes.post("/regenerate", async (c) => {
  const schema = z.object({ messageId: z.string() });
  const body = schema.safeParse(await c.req.json().catch(() => ({})));
  if (!body.success) return c.json({ error: "طلب غير صالح" }, 400);
  const msg = await get<{ id: string; conversation_id: string }>("SELECT id,conversation_id FROM messages WHERE id=?", [body.data.messageId]);
  if (!msg) return c.json({ error: "الرسالة غير موجودة" }, 404);
  // آخر رسالة مستخدم قبل هذه الرسالة المساعد
  const prevUser = await get<{ content: string; attachments: string }>(
    "SELECT content,attachments FROM messages WHERE conversation_id=? AND role='user' AND created_at < (SELECT created_at FROM messages WHERE id=?) ORDER BY created_at DESC LIMIT 1",
    [msg.conversation_id, msg.id],
  );
  if (!prevUser) return c.json({ error: "لا توجد رسالة مستخدم سابقة" }, 400);
  await run("UPDATE messages SET content='', status='streaming' WHERE id=?", [msg.id]);
  const controller = new AbortController();
  aborts.set(msg.id, controller);
  return streamAnswer(
    c, msg.conversation_id, msg.id, prevUser.content,
    JSON.parse(prevUser.attachments || "[]") as string[], controller,
  );
});

chatRoutes.post("/stop", async (c) => {
  const schema = z.object({ messageId: z.string() });
  const body = schema.safeParse(await c.req.json().catch(() => ({})));
  if (!body.success) return c.json({ error: "طلب غير صالح" }, 400);
  const a = aborts.get(body.data.messageId);
  if (a) a.abort();
  const msg = await get<{ content: string }>("SELECT content FROM messages WHERE id=?", [body.data.messageId]);
  const finalStatus = msg && msg.content.length > 0 ? "stopped" : "error";
  await run("UPDATE messages SET status=? WHERE id=? AND status='streaming'", [finalStatus, body.data.messageId]);
  return c.json({ ok: true });
});

function sse(enc: InstanceType<typeof TextEncoder>, obj: unknown): Uint8Array {
  return enc.encode(`data: ${JSON.stringify(obj)}\n\n`);
}

async function streamAnswer(
  c: Context,
  convId: string,
  assistantId: string,
  userContent: string,
  fileIds: string[],
  controller: AbortController,
) {
  const enc = new TextEncoder();
  const response = stream(c, async (writer) => {
    const write = async (obj: unknown) => writer.write(sse(enc, obj));
    try {
      await write({ type: "start", conversationId: convId, messageId: assistantId });
      // بناء السياق: تعليمات نظام + سجل المحادثة + المرفقات
      const history = await all<{ role: string; content: string }>(
        "SELECT role,content FROM messages WHERE conversation_id=? AND status IN ('complete','stopped') ORDER BY created_at ASC LIMIT 40",
        [convId],
      );
      const skillContext = await buildSystemContext(userContent);
      const contextLen = Number(await getSetting("context_length")) || 4096;
      const messages: ChatMessage[] = [];
      let sys = "أنت One AI، مساعد ذكاء اصطناعي مفيد ودقيق.";
      if (skillContext) sys += "\n\n" + skillContext;
      sys += `\n\n(حد السياق: ${contextLen} رمزاً تقريباً)`;
      messages.push({ role: "system", content: sys });

      const attachments: string[] = [];
      const images: string[] = [];
      for (const fid of fileIds) {
        const part = await fileToPart(fid);
        if (!part) continue;
        if (part.image) {
          const abs = new URL(part.image, "http://localhost").pathname;
          images.push(`http://127.0.0.1:${process.env.PORT ?? 3000}${abs}`);
        }
        if (part.text) attachments.push(part.text.slice(0, 6000));
      }
      const fileNote = attachments.length
        ? `\n\n[محتوى الملفات المرفقة]\n${attachments.join("\n\n---\n\n")}`
        : "";
      for (const h of history) {
        if (h.role === "user" || h.role === "assistant") {
          messages.push({ role: h.role, content: h.role === "user" ? h.content + (h === history[history.length - 1] ? fileNote : "") : h.content });
        }
      }
      // الرسالة الأخيرة دائماً رسالة المستخدم الحالية (حتى لو لم تكن في التاريخ بعد)
      const lastMsg = messages[messages.length - 1];
      if (!lastMsg || lastMsg.role !== "user" || lastMsg.content !== userContent + fileNote) {
        messages.push({ role: "user", content: userContent + fileNote });
      }

      let acc = "";
      try {
        for await (const token of chat({ messages, signal: controller.signal, images })) {
          acc += token;
          await write({ type: "token", token });
          if (acc.length % 2000 < token.length) {
            await run("UPDATE messages SET content=? WHERE id=?", [acc, assistantId]);
          }
        }
      } catch (err) {
        if (controller.signal.aborted) {
          await run("UPDATE messages SET content=?, status='stopped' WHERE id=?", [acc, assistantId]);
          await write({ type: "stopped", content: acc });
        } else {
          log.error("chat engine error", { error: err instanceof Error ? err.message : String(err) });
          const msg = err instanceof Error ? err.message : "خطأ غير متوقع";
          await run("UPDATE messages SET content=?, status='error' WHERE id=?", [acc, assistantId]);
          await write({ type: "error", message: msg });
        }
        await writer.close();
        return;
      }
      await run("UPDATE messages SET content=?, status='complete' WHERE id=?", [acc, assistantId]);
      await run("UPDATE conversations SET updated_at=? WHERE id=?", [Date.now(), convId]);
      await write({ type: "done", content: acc });
      await writer.close();
    } finally {
      aborts.delete(assistantId);
    }
  });
  return response;
}

chatRoutes.get("/engine", async (c) => {
  return c.json(await engineInfo());
});

export { aborts as chatAborts };
