/**
 * توليد الصور — مزوّد حقيقي اختياري (واجهة Stable Diffusion/A1111 على جهاز المستخدم).
 * إذا لم يُضبط endpoint تُعاد الحالة "معطّل" بوضوح — لا محاكاة.
 */
import fs from "node:fs";
import path from "node:path";
import { Hono } from "hono";
import { z } from "zod";
import { all, run, dataDir } from "../db";
import { getSetting } from "../lib/settings";
import { log } from "../lib/logger";

export const imagegenRoutes = new Hono();

imagegenRoutes.get("/status", async (c) => {
  const endpoint = (await getSetting("imagegen_endpoint")).trim();
  return c.json({ configured: endpoint.length > 0, endpoint: endpoint ? mask(endpoint) : "" });
});

function mask(url: string): string {
  try {
    const u = new URL(url);
    return `${u.protocol}//${u.host}`;
  } catch {
    return "";
  }
}

const genSchema = z.object({
  prompt: z.string().min(1).max(2000),
  negative: z.string().max(1000).default(""),
  width: z.number().int().min(256).max(1024).default(512),
  height: z.number().int().min(256).max(1024).default(512),
  steps: z.number().int().min(1).max(60).default(25),
  quality: z.enum(["fast", "balanced", "high"]).default("balanced"),
});

imagegenRoutes.post("/generate", async (c) => {
  const endpoint = (await getSetting("imagegen_endpoint")).trim();
  if (!endpoint) {
    return c.json(
      { error: "توليد الصور غير مفعّل. اضبط عنوان Stable Diffusion (A1111) خاص بك من الإعدادات لتفعيله.", disabled: true },
      409,
    );
  }
  const body = genSchema.safeParse(await c.req.json().catch(() => {}));
  if (!body.success) return c.json({ error: "معاملات غير صالحة" }, 400);
  const d = body.data;
  const steps = d.quality === "fast" ? Math.min(d.steps, 15) : d.quality === "high" ? Math.max(d.steps, 35) : d.steps;
  try {
    const res = await fetch(`${endpoint.replace(/\/+$/, "")}/sdapi/v1/txt2img`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        prompt: d.prompt,
        negative_prompt: d.negative,
        width: d.width,
        height: d.height,
        steps,
      }),
      signal: AbortSignal.timeout(180000),
    });
    if (!res.ok) {
      return c.json({ error: `خادم التوليد أعاد خطأً (${res.status}) — تأكد أن Stable Diffusion يعمل` }, 502);
    }
    const data = (await res.json()) as { images: string[] };
    if (!data.images?.[0]) return c.json({ error: "لم يُرجع الخادم صورة" }, 502);
    const png = Buffer.from(data.images[0], "base64");
    const id = crypto.randomUUID();
    const dir = path.join(dataDir(), "files");
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, `${id}.png`), png);
    await run("INSERT INTO files(id,filename,mime,size,kind,text,created_at) VALUES(?,?,?,?,?,'',?)", [
      id, `generated-${id.slice(0, 8)}.png`, "image/png", png.length, "image-gen", Date.now(),
    ]);
    return c.json({ id, url: `/api/files/${id}/raw`, size: png.length });
  } catch (err) {
    log.error("imagegen failed", { error: err instanceof Error ? err.message : String(err) });
    return c.json({ error: "تعذّر الوصول إلى خادم التوليد — تحقق من العنوان والشبكة" }, 502);
  }
});

imagegenRoutes.get("/history", async (c) => {
  const rows = await all<{ id: string; filename: string; size: number; created_at: number }>(
    "SELECT id,filename,size,created_at FROM files WHERE kind='image-gen' ORDER BY created_at DESC LIMIT 24",
  );
  return c.json(rows.map((r) => ({ ...r, url: `/api/files/${r.id}/raw` })));
});
