/**
 * الملفات — رفع/عرض/حذف مع التحقق من النوع (Magic Bytes) واستخراج نص PDF/TXT.
 */
import fs from "node:fs";
import path from "node:path";
import { Hono } from "hono";
import { all, get, run, dataDir } from "../db";
import { log } from "../lib/logger";
import { pdfParse } from "../lib/shims";

export const filesRoutes = new Hono();

const FILES_DIR = () => path.join(dataDir(), "files");
const MAX_SIZE = 15 * 1024 * 1024; // 15MB

const ALLOWED: Record<string, { mime: string; kind: string }> = {
  txt: { mime: "text/plain", kind: "text" },
  md: { mime: "text/markdown", kind: "text" },
  pdf: { mime: "application/pdf", kind: "pdf" },
  png: { mime: "image/png", kind: "image" },
  jpg: { mime: "image/jpeg", kind: "image" },
  jpeg: { mime: "image/jpeg", kind: "image" },
  webp: { mime: "image/webp", kind: "image" },
  gif: { mime: "image/gif", kind: "image" },
};

/** كشف النوع الحقيقي من البايتات الأولى — لا نثق بالامتداد */
function sniffKind(buf: Buffer): string | null {
  if (buf.slice(0, 4).toString("latin1") === "%PDF") return "pdf";
  if (buf.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return "image";
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return "image";
  if (buf.slice(0, 4).toString("latin1") === "RIFF" && buf.slice(8, 12).toString("latin1") === "WEBP") return "image";
  // نص قابل للقراءة: يجب أن يكون UTF-8 صالحاً (فحص صارم) وبلا بايتات تحكم
  try {
    const sample = new TextDecoder("utf-8", { fatal: true }).decode(buf.slice(0, 512));
    const bad = [...sample].filter((ch) => {
      const code = ch.codePointAt(0)!;
      return code < 32 && code !== 9 && code !== 10 && code !== 13;
    }).length;
    if (bad === 0) return "text";
  } catch {
    /* ترميز غير صالح */
  }
  return null;
}

async function extractPdfText(p: string): Promise<string> {
  const data = await pdfParse(fs.readFileSync(p));
  return (data.text || "").replace(/\s+/g, " ").trim().slice(0, 20000);
}

filesRoutes.post("/upload", async (c) => {
  const body = await c.req.parseBody();
  const file = body.file;
  if (!(file instanceof File)) return c.json({ error: "لا يوجد ملف" }, 400);
  if (file.size > MAX_SIZE) return c.json({ error: "الحد الأقصى 15MB" }, 413);
  const buf = Buffer.from(await file.arrayBuffer());
  const kind = sniffKind(buf);
  if (!kind) return c.json({ error: "نوع الملف غير مدعوم (PDF/TXT/MD/صور فقط)" }, 415);
  const id = crypto.randomUUID();
  fs.mkdirSync(FILES_DIR(), { recursive: true });
  const ext = path.extname(file.name).slice(1).toLowerCase() || (kind === "image" ? "png" : "txt");
  const p = path.join(FILES_DIR(), `${id}.${ext}`);
  fs.writeFileSync(p, buf);
  let text = "";
  if (kind === "pdf") {
    try {
      text = await extractPdfText(p);
    } catch (err) {
      log.warn("pdf extraction failed", { error: String(err) });
      text = "";
    }
  } else if (kind === "text") {
    text = buf.toString("utf8").slice(0, 20000);
  }
  await run("INSERT INTO files(id,filename,mime,size,kind,text,created_at) VALUES(?,?,?,?,?,?,?)", [
    id, file.name, (ALLOWED[ext]?.mime ?? file.type) || "application/octet-stream", buf.length, kind, text, Date.now(),
  ]);
  return c.json({ id, filename: file.name, size: buf.length, kind });
});

filesRoutes.get("", async (c) => {
  const rows = await all<{ id: string; filename: string; mime: string; size: number; kind: string; created_at: number; text: string }>(
    "SELECT id,filename,mime,size,kind,created_at,text FROM files ORDER BY created_at DESC",
  );
  return c.json(rows.map((r) => ({ ...r, hasText: r.text.length > 0, text: undefined })));
});

filesRoutes.get("/:id/raw", async (c) => {
  const f = await get<{ id: string; mime: string }>("SELECT id,mime FROM files WHERE id=?", [c.req.param("id")]);
  if (!f) return c.json({ error: "غير موجود" }, 404);
  const dir = fs.readdirSync(FILES_DIR());
  const match = dir.find((n) => n.startsWith(f.id + "."));
  if (!match) return c.json({ error: "الملف مفقود من القرص" }, 404);
  const buf = fs.readFileSync(path.join(FILES_DIR(), match));
  return new Response(new Uint8Array(buf), { headers: { "Content-Type": f.mime, "Cache-Control": "private, max-age=3600" } });
});

filesRoutes.get("/:id", async (c) => {
  const f = await get("SELECT * FROM files WHERE id=?", [c.req.param("id")]);
  if (!f) return c.json({ error: "غير موجود" }, 404);
  return c.json(f);
});

filesRoutes.delete("/:id", async (c) => {
  const f = await get<{ id: string }>("SELECT id FROM files WHERE id=?", [c.req.param("id")]);
  if (!f) return c.json({ error: "غير موجود" }, 404);
  const dir = fs.existsSync(FILES_DIR()) ? fs.readdirSync(FILES_DIR()) : [];
  const match = dir.find((n) => n.startsWith(f.id + "."));
  if (match) fs.rmSync(path.join(FILES_DIR(), match), { force: true });
  await run("DELETE FROM files WHERE id=?", [f.id]);
  return c.json({ ok: true });
});
