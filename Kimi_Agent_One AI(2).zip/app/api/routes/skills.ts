/**
 * Skills — إدارة كاملة عبر REST (الواجهة تستدعيها مباشرة).
 */
import fs from "node:fs";
import path from "node:path";
import { Hono } from "hono";
import { z } from "zod";
import { all, get, run, dataDir } from "../db";
import { chunkText } from "../lib/skills";
import { log } from "../lib/logger";
import { pdfParse } from "../lib/shims";

export const skillsRoutes = new Hono();

skillsRoutes.get("/", async (c) => {
  const skills = await all("SELECT * FROM skills ORDER BY builtin DESC, created_at ASC");
  const out = [];
  for (const s of skills) {
    const kn = await all("SELECT id,filename,created_at FROM skill_knowledge WHERE skill_id=?", [s.id]);
    out.push({ ...s, knowledge: kn });
  }
  return c.json(out);
});

const skillSchema = z.object({
  name: z.string().min(1).max(80),
  name_ar: z.string().max(80).default(""),
  description: z.string().max(300).default(""),
  description_ar: z.string().max(300).default(""),
  prompt: z.string().max(4000).default(""),
});

skillsRoutes.post("/", async (c) => {
  const body = skillSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!body.success) return c.json({ error: "بيانات غير صالحة" }, 400);
  const id = crypto.randomUUID();
  await run(
    "INSERT INTO skills(id,name,name_ar,description,description_ar,prompt,builtin,enabled,created_at) VALUES(?,?,?,?,?,?,0,1,?)",
    [id, body.data.name, body.data.name_ar, body.data.description, body.data.description_ar, body.data.prompt, Date.now()],
  );
  return c.json({ id });
});

skillsRoutes.put("/:id", async (c) => {
  const existing = await get("SELECT id FROM skills WHERE id=?", [c.req.param("id")]);
  if (!existing) return c.json({ error: "غير موجود" }, 404);
  const body = skillSchema.partial().safeParse(await c.req.json().catch(() => ({})));
  if (!body.success) return c.json({ error: "بيانات غير صالحة" }, 400);
  const d = body.data;
  const fields: string[] = [];
  const vals: (string | number)[] = [];
  for (const k of ["name", "name_ar", "description", "description_ar", "prompt"] as const) {
    if (d[k] !== undefined) {
      fields.push(`${k}=?`);
      vals.push(d[k]!);
    }
  }
  if (fields.length) await run(`UPDATE skills SET ${fields.join(",")} WHERE id=?`, [...vals, c.req.param("id")]);
  return c.json({ ok: true });
});

skillsRoutes.post("/:id/toggle", async (c) => {
  const s = await get<{ enabled: number; builtin: number }>("SELECT enabled,builtin FROM skills WHERE id=?", [c.req.param("id")]);
  if (!s) return c.json({ error: "غير موجود" }, 404);
  await run("UPDATE skills SET enabled=? WHERE id=?", [s.enabled ? 0 : 1, c.req.param("id")]);
  return c.json({ ok: true, enabled: !s.enabled });
});

skillsRoutes.delete("/:id", async (c) => {
  const s = await get<{ builtin: number }>("SELECT builtin FROM skills WHERE id=?", [c.req.param("id")]);
  if (!s) return c.json({ error: "غير موجود" }, 404);
  if (s.builtin) return c.json({ error: "لا يمكن حذف مهارة مدمجة — عطّلها بدلاً من ذلك" }, 400);
  await run("DELETE FROM skills WHERE id=?", [c.req.param("id")]);
  return c.json({ ok: true });
});

/** رفع ملف معرفة (TXT/MD/PDF) لمهارة */
skillsRoutes.post("/:id/knowledge", async (c) => {
  const s = await get("SELECT id FROM skills WHERE id=?", [c.req.param("id")]);
  if (!s) return c.json({ error: "المهارة غير موجودة" }, 404);
  const body = await c.req.parseBody();
  const file = body.file;
  if (!(file instanceof File)) return c.json({ error: "لا يوجد ملف" }, 400);
  const buf = Buffer.from(await file.arrayBuffer());
  if (buf.length > 10 * 1024 * 1024) return c.json({ error: "الحد الأقصى 10MB" }, 413);
  const ext = path.extname(file.name).slice(1).toLowerCase();
  let text = "";
  if (ext === "pdf" || buf.slice(0, 4).toString("latin1") === "%PDF") {
    try {
      text = (await pdfParse(buf)).text || "";
    } catch (err) {
      log.warn("knowledge pdf parse failed", { error: String(err) });
      return c.json({ error: "تعذّرت قراءة ملف PDF" }, 422);
    }
  } else {
    text = buf.toString("utf8");
    if (text.includes("")) return c.json({ error: "الملف ليس نصاً قابلاً للقراءة" }, 415);
  }
  text = text.replace(/\s+/g, " ").trim();
  if (!text) return c.json({ error: "المحتوى فارغ" }, 422);
  // تحقق من عدم وجود محتوى تنفيذي — المعرفة نصية فقط
  const id = crypto.randomUUID();
  await run("INSERT INTO skill_knowledge(id,skill_id,filename,content,created_at) VALUES(?,?,?,?,?)", [
    id, c.req.param("id"), file.name, text, Date.now(),
  ]);
  return c.json({ id, chunks: chunkText(text).length });
});

skillsRoutes.delete("/knowledge/:kid", async (c) => {
  await run("DELETE FROM skill_knowledge WHERE id=?", [c.req.param("kid")]);
  return c.json({ ok: true });
});
