import { describe, it, expect } from "vitest";
import { clampPercent } from "./downloads";

describe("clampPercent — نسبة التنزيل", () => {
  it("يحسب النسبة بشكل صحيح", () => {
    expect(clampPercent(50, 100)).toBe(50);
    expect(clampPercent(1, 3)).toBe(33.3);
  });

  it("لا يتجاوز 100% أبداً حتى مع بيانات خاطئة", () => {
    expect(clampPercent(150, 100)).toBe(100);
    expect(clampPercent(Number.MAX_SAFE_INTEGER, 1)).toBe(100);
    // تقدير الحجم الأصلي أصغر من الحجم الفعلي (تحديث الحجم من الخادم)
    expect(clampPercent(4_700_000_000, 4_680_000_000)).toBe(100);
  });

  it("لا يعطي قيماً سالبة", () => {
    expect(clampPercent(-10, 100)).toBe(0);
  });

  it("يعيد صفراً عند غياب الإجمالي", () => {
    expect(clampPercent(100, 0)).toBe(0);
    expect(clampPercent(100, -5)).toBe(0);
  });
});
