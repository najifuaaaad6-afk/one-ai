import { describe, it, expect } from "vitest";
import { chunkText, scoreChunk } from "./skills";

describe("chunkText — تقسيم المعرفة", () => {
  it("يقسم النص الطويل إلى كتل متداخلة", () => {
    const text = "كلمة ".repeat(500);
    const chunks = chunkText(text, 100, 20);
    expect(chunks.length).toBeGreaterThan(5);
    // كل كتلة ضمن الحجم المطلوب تقريباً
    expect(chunks[0].length).toBeLessThanOrEqual(101);
  });

  it("يعيد قائمة فارغة لنص فارغ", () => {
    expect(chunkText("")).toEqual([]);
    expect(chunkText("   \n  ")).toEqual([]);
  });

  it("يتعامل مع النص القصير", () => {
    expect(chunkText("مرحبا")).toEqual(["مرحبا"]);
  });
});

describe("scoreChunk — ترتيب الصلة", () => {
  it("يعطي درجة أعلى للكتل المتطابقة", () => {
    const q = "ما هي عاصمة فرنسا";
    const relevant = "فرنسا بلد أوروبي وعاصمته باريس";
    const irrelevant = "البرمجة لغات بايثون جافا سكربت";
    expect(scoreChunk(q, relevant)).toBeGreaterThan(scoreChunk(q, irrelevant));
  });

  it("يعيد صفراً لاستعلام بلا كلمات ذات معنى", () => {
    expect(scoreChunk("!!", "أي نص")).toBe(0);
  });
});
