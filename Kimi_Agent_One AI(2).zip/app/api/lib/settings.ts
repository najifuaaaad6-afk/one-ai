import { all, run } from "../db";

/** إعدادات مفتاح/قيمة مخزنة محلياً */
export async function getSetting(key: string): Promise<string> {
  const row = await all<{ value: string }>("SELECT value FROM settings WHERE key = ?", [key]);
  return row[0]?.value ?? "";
}

export async function getSettings(keys: string[]): Promise<Record<string, string>> {
  const out: Record<string, string> = {};
  for (const k of keys) out[k] = await getSetting(k);
  return out;
}

export async function setSetting(key: string, value: string): Promise<void> {
  await run("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", [key, value]);
}
