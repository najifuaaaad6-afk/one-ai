/**
 * غلافات مكتوبة الأنواع لمكتبات بلا تعريفات TypeScript رسمية.
 * الاستيراد يتم هنا فقط حتى تبقى الأنواع صحيحة في بقية الكود.
 */

// @ts-expect-error pdf-parse بلا أنواع رسمية
import pdfParseImport from "pdf-parse";
export const pdfParse = pdfParseImport as unknown as (buf: Buffer) => Promise<{ text: string; numpages: number }>;

// @ts-expect-error النسخة المضمّنة من sql.js بلا أنواع رسمية لهذا المسار
import initSqlJsImport from "sql.js/dist/sql-wasm-inline.js";
import type { SqlJsStatic } from "sql.js";
export const initSqlJsInline = initSqlJsImport as unknown as (config?: unknown) => Promise<SqlJsStatic>;
