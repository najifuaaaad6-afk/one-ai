/**
 * مدير التنزيلات — نسبة حقيقية من بايتات فعلية، استئناف عبر Range، تحقق SHA-256.
 * النسبة = المحمّل/الإجمالي ولا تتجاوز 100% أبداً (مضمون حسابياً عبر clampPercent).
 */
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { all, get, run, dataDir } from "../db";
import { log } from "./logger";

export interface ModelRow {
  id: string;
  level: string;
  name: string;
  repo: string;
  filename: string;
  url: string;
  size_bytes: number;
  sha256: string;
  status: string;
  progress_bytes: number;
  path: string;
  error: string;
  updated_at: number;
}

export function clampPercent(loaded: number, total: number): number {
  if (total <= 0) return 0;
  return Math.min(100, Math.max(0, Math.round((loaded / total) * 1000) / 10));
}

const MODELS_DIR = () => path.join(dataDir(), "models");

/** كتالوج النماذج — نماذج GGUF مفتوحة المصدر حقيقية من Hugging Face */
export const MODEL_CATALOG: Omit<ModelRow, "status" | "progress_bytes" | "path" | "error" | "updated_at">[] = [
  {
    id: "beta-qwen05b",
    level: "Beta",
    name: "Qwen 2.5 0.5B Instruct",
    repo: "Qwen/Qwen2.5-0.5B-Instruct-GGUF",
    filename: "qwen2.5-0.5b-instruct-q4_k_m.gguf",
    url: "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf",
    size_bytes: 352_000_000,
    sha256: "",
  },
  {
    id: "alpha-qwen15b",
    level: "Alpha",
    name: "Qwen 2.5 1.5B Instruct",
    repo: "Qwen/Qwen2.5-1.5B-Instruct-GGUF",
    filename: "qwen2.5-1.5b-instruct-q4_k_m.gguf",
    url: "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf",
    size_bytes: 986_000_000,
    sha256: "",
  },
  {
    id: "gamma-qwen7b",
    level: "Gamma",
    name: "Qwen 2.5 7B Instruct",
    repo: "Qwen/Qwen2.5-7B-Instruct-GGUF",
    filename: "qwen2.5-7b-instruct-q4_k_m.gguf",
    url: "https://huggingface.co/Qwen/Qwen2.5-7B-Instruct-GGUF/resolve/main/qwen2.5-7b-instruct-q4_k_m.gguf",
    size_bytes: 4_680_000_000,
    sha256: "",
  },
];

interface ActiveDownload {
  abort: AbortController;
  startedAt: number;
}
const active = new Map<string, ActiveDownload>();

export async function syncCatalog(): Promise<void> {
  const now = Date.now();
  for (const m of MODEL_CATALOG) {
    await run(
      `INSERT INTO models(id,level,name,repo,filename,url,size_bytes,sha256,status,progress_bytes,path,error,updated_at)
       VALUES(?,?,?,?,?,?,?,?,'none',0,'','',?)
       ON CONFLICT(id) DO UPDATE SET
         name=excluded.name, repo=excluded.repo, filename=excluded.filename,
         url=excluded.url, size_bytes=excluded.size_bytes, sha256=excluded.sha256, updated_at=excluded.updated_at`,
      [m.id, m.level, m.name, m.repo, m.filename, m.url, m.size_bytes, m.sha256, now],
    );
  }
}

export async function listModels(): Promise<ModelRow[]> {
  return all<ModelRow>("SELECT * FROM models ORDER BY CASE level WHEN 'Beta' THEN 0 WHEN 'Alpha' THEN 1 ELSE 2 END");
}

function filePathFor(m: ModelRow): string {
  return path.join(MODELS_DIR(), m.filename);
}

async function fetchSha256FromHub(repo: string, filename: string): Promise<string> {
  try {
    const res = await fetch(`https://huggingface.co/api/models/${repo}?blobs=true`, {
      signal: AbortSignal.timeout(10000),
    });
    if (!res.ok) return "";
    const data = (await res.json()) as { siblings?: { rfilename: string; lfs?: { oid: string } }[] };
    const sib = data.siblings?.find((s) => s.rfilename === filename);
    return sib?.lfs?.oid ?? "";
  } catch {
    return "";
  }
}

async function sha256File(p: string): Promise<string> {
  const hash = crypto.createHash("sha256");
  await new Promise<void>((resolve, reject) => {
    const stream = fs.createReadStream(p);
    stream.on("data", (d) => hash.update(d));
    stream.on("end", () => resolve());
    stream.on("error", reject);
  });
  return hash.digest("hex");
}

async function doDownload(id: string): Promise<void> {
  const m = await get<ModelRow>("SELECT * FROM models WHERE id = ?", [id]);
  if (!m) return;
  fs.mkdirSync(MODELS_DIR(), { recursive: true });
  const filePath = filePathFor(m);
  const existing = fs.existsSync(filePath) ? fs.statSync(filePath).size : 0;
  const controller = new AbortController();
  active.set(id, { abort: controller, startedAt: Date.now() });
  try {
    await run("UPDATE models SET status='downloading', error='' WHERE id=?", [id]);
    // لا نعيد تحميل ملف مكتمل سليم
    if (existing >= m.size_bytes && m.status === "installed") {
      await run("UPDATE models SET progress_bytes=? WHERE id=?", [m.size_bytes, id]);
      return;
    }
    const headers: Record<string, string> = {};
    if (existing > 0) headers.Range = `bytes=${existing}-`;
    const res = await fetch(m.url, { headers, signal: controller.signal, redirect: "follow" });
    if (!res.ok && res.status !== 206) {
      throw new Error(`تعذّر التنزيل: HTTP ${res.status}`);
    }
    // حجم فعلي من الترويسات عند توفره (أدق من التقدير)
    const totalFromServer = res.ok
      ? Number(res.headers.get("content-length") ?? 0) + existing
      : Number(res.headers.get("content-range")?.split("/")[1] ?? 0) || existing + Number(res.headers.get("content-length") ?? 0);
    if (totalFromServer > 0 && Math.abs(totalFromServer - m.size_bytes) > 1) {
      await run("UPDATE models SET size_bytes=? WHERE id=?", [totalFromServer, id]);
      m.size_bytes = totalFromServer;
    }
    const append = res.status === 206 && existing > 0;
    const fh = fs.openSync(filePath, append ? "a" : "w");
    try {
      const reader = res.body!.getReader();
      let received = existing;
      const started = Date.now();
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        fs.writeSync(fh, value);
        received += value.byteLength;
        await run("UPDATE models SET progress_bytes=? WHERE id=?", [Math.min(received, m.size_bytes), id]);
      }
      // حساب السرعة وكتابتها في السجل — البيانات الحية تُقرأ من قاعدة البيانات
      const secs = (Date.now() - started) / 1000;
      log.info("model download chunk finished", { id, bytes: received - existing, secs });
    } finally {
      fs.closeSync(fh);
    }
    if (controller.signal.aborted) {
      await run("UPDATE models SET status='paused' WHERE id=?", [id]);
      return;
    }
    const finalSize = fs.statSync(filePath).size;
    if (finalSize < m.size_bytes) {
      throw new Error(`ملف غير مكتمل (${finalSize}/${m.size_bytes} بايت) — أعد المحاولة لاستئناف التنزيل`);
    }
    // التحقق من السلامة عند توفر بصمة SHA-256 من Hugging Face
    const expected = m.sha256 || (await fetchSha256FromHub(m.repo, m.filename));
    if (expected) {
      await run("UPDATE models SET status='verifying' WHERE id=?", [id]);
      const actual = await sha256File(filePath);
      if (actual !== expected) {
        fs.rmSync(filePath, { force: true });
        throw new Error("فشل التحقق من سلامة الملف (SHA-256) — حُذف الملف وحاول مجدداً");
      }
      await run("UPDATE models SET sha256=? WHERE id=?", [expected, id]);
    }
    await run("UPDATE models SET status='installed', progress_bytes=size_bytes, path=? WHERE id=?", [filePath, id]);
    log.info("model installed", { id, size: finalSize });
  } catch (err) {
    if (controller.signal.aborted) {
      await run("UPDATE models SET status='paused' WHERE id=?", [id]);
    } else {
      const msg = err instanceof Error ? err.message : String(err);
      await run("UPDATE models SET status='error', error=? WHERE id=?", [msg.slice(0, 300), id]);
      log.error("download failed", { id, error: msg });
    }
  } finally {
    active.delete(id);
  }
}

export async function startDownload(id: string): Promise<{ ok: boolean; error?: string }> {
  const m = await get<ModelRow>("SELECT * FROM models WHERE id=?", [id]);
  if (!m) return { ok: false, error: "النموذج غير موجود" };
  if (active.has(id)) return { ok: true };
  const filePath = filePathFor(m);
  if (m.status === "installed" && fs.existsSync(filePath) && fs.statSync(filePath).size >= m.size_bytes) {
    return { ok: true };
  }
  void doDownload(id);
  return { ok: true };
}

export async function pauseDownload(id: string): Promise<void> {
  const a = active.get(id);
  if (a) a.abort.abort();
  await run("UPDATE models SET status='paused' WHERE id=?", [id]);
}

export async function resumeDownload(id: string): Promise<{ ok: boolean; error?: string }> {
  return startDownload(id); // الاستئناف تلقائي عبر Range من حجم الملف الحالي
}

export async function cancelDownload(id: string): Promise<void> {
  const a = active.get(id);
  if (a) a.abort.abort();
  const m = await get<ModelRow>("SELECT * FROM models WHERE id=?", [id]);
  if (m?.path && fs.existsSync(m.path)) fs.rmSync(m.path, { force: true });
  await run("UPDATE models SET status='none', progress_bytes=0, path='', error='' WHERE id=?", [id]);
}

export async function deleteModel(id: string): Promise<void> {
  await pauseDownload(id);
  const m = await get<ModelRow>("SELECT * FROM models WHERE id=?", [id]);
  if (m?.path && fs.existsSync(m.path)) fs.rmSync(m.path, { force: true });
  await run("UPDATE models SET status='none', progress_bytes=0, path='', error='' WHERE id=?", [id]);
}
