/**
 * نظام Skills — بناء سياق النظام من المهارات المفعّلة ومعرفتها.
 * الاسترجاع: تداخل مصطلحات بسيط (TF بدائي) فوق مقاطع المعرفة — صادق وقابل للتوسع.
 */
import { all } from "../db";

export interface SkillRow {
  id: string;
  name: string;
  name_ar: string;
  description: string;
  prompt: string;
  enabled: number;
}

/** تقسيم النص إلى كتل متداخلة للاسترجاع */
export function chunkText(text: string, size = 500, overlap = 100): string[] {
  const clean = text.replace(/\s+/g, " ").trim();
  if (!clean) return [];
  const chunks: string[] = [];
  let start = 0;
  while (start < clean.length) {
    chunks.push(clean.slice(start, start + size));
    if (start + size >= clean.length) break;
    start += size - overlap;
  }
  return chunks;
}

/** درجة تطابق رسالة المستخدم مع كتلة معرفة — تداخل مصطلحات مُرجَّح */
export function scoreChunk(query: string, chunk: string): number {
  const terms = query
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .split(/\s+/)
    .filter((t) => t.length > 2);
  if (terms.length === 0) return 0;
  const hay = chunk.toLowerCase();
  let score = 0;
  for (const t of terms) {
    if (hay.includes(t)) score += t.length;
  }
  return score / (terms.length * 8); // تطبيع تقريبي
}

/** يبني تعليمات النظام من المهارات المفعّلة + أفضل مقاطع المعرفة المرتبطة */
export async function buildSystemContext(userMessage: string): Promise<string> {
  const skills = await all<SkillRow>(
    "SELECT id,name,name_ar,description,prompt,enabled FROM skills WHERE enabled = 1",
  );
  if (skills.length === 0) return "";
  const parts: string[] = [];
  for (const s of skills) {
    if (s.prompt) parts.push(`[Skill: ${s.name}]\n${s.prompt}`);
    const knowledge = await all<{ content: string }>(
      "SELECT content FROM skill_knowledge WHERE skill_id = ?",
      [s.id],
    );
    if (knowledge.length > 0) {
      const chunks = knowledge.flatMap((k) => chunkText(k.content)).slice(0, 60);
      const ranked = chunks
        .map((c) => ({ c, score: scoreChunk(userMessage, c) }))
        .filter((x) => x.score > 0)
        .sort((a, b) => b.score - a.score)
        .slice(0, 3)
        .map((x) => x.c);
      if (ranked.length > 0) {
        parts.push(`[Knowledge: ${s.name}]\n${ranked.join("\n---\n")}`);
      }
    }
  }
  return parts.join("\n\n");
}
