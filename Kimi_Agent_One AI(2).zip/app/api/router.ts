import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { all, get, run } from "./db";
import { setSetting } from "./lib/settings";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),

  conversations: createRouter({
    list: publicQuery.query(async () => {
      const rows = await all(
        "SELECT id,title,created_at,updated_at,pinned FROM conversations ORDER BY pinned DESC, updated_at DESC LIMIT 200",
      );
      return rows.map((r) => ({
        id: String(r.id),
        title: String(r.title ?? ""),
        created_at: Number(r.created_at),
        updated_at: Number(r.updated_at),
        pinned: Number(r.pinned),
      }));
    }),
    get: publicQuery.input(z.object({ id: z.string() })).query(async ({ input }) => {
      const conv = await get("SELECT id,title,created_at,updated_at,pinned FROM conversations WHERE id=?", [input.id]);
      if (!conv) return null;
      const messages = await all(
        "SELECT id,role,content,status,attachments,created_at FROM messages WHERE conversation_id=? ORDER BY created_at ASC",
        [input.id],
      );
      return {
        ...conv,
        messages: messages.map((m) => ({
          id: String(m.id),
          role: String(m.role),
          content: String(m.content ?? ""),
          status: String(m.status ?? "complete"),
          attachments: String(m.attachments ?? "[]"),
          created_at: Number(m.created_at),
        })),
      };
    }),
    rename: publicQuery
      .input(z.object({ id: z.string(), title: z.string().min(1).max(120) }))
      .mutation(async ({ input }) => {
        await run("UPDATE conversations SET title=?, updated_at=? WHERE id=?", [input.title, Date.now(), input.id]);
        return { ok: true };
      }),
    pin: publicQuery.input(z.object({ id: z.string(), pinned: z.boolean() })).mutation(async ({ input }) => {
      await run("UPDATE conversations SET pinned=? WHERE id=?", [input.pinned ? 1 : 0, input.id]);
      return { ok: true };
    }),
    delete: publicQuery.input(z.object({ id: z.string() })).mutation(async ({ input }) => {
      await run("DELETE FROM conversations WHERE id=?", [input.id]);
      return { ok: true };
    }),
  }),

  settings: createRouter({
    getAll: publicQuery.query(async () => {
      const rows = await all<{ key: string; value: string }>("SELECT key,value FROM settings");
      const out: Record<string, string> = {};
      for (const r of rows) out[r.key] = r.value;
      // لا نُرجع المفتاح الخاص أبداً
      if (out.remote_key) out.remote_key = "••••••";
      return out;
    }),
    set: publicQuery
      .input(z.object({ key: z.string().min(1).max(60), value: z.string().max(2000) }))
      .mutation(async ({ input }) => {
        if (input.key === "remote_key" && input.value === "••••••") return { ok: true };
        await setSetting(input.key, input.value);
        return { ok: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
