/**
 * One AI — محرك المحادثة
 *
 * واجهة موحدة أمام محركين حقيقيين:
 *  - "local": بوابة النماذج المضمّنة في المنصة (AI SDK) — يعمل فوراً دون إعداد.
 *  - "remote": خادم llama.cpp خاص يشغّله المستخدم على جهازه (خيار السيرفر الخاص).
 *
 * لا يوجد أي محاكاة: إذا تعذّر المحرك أُبلغ العميل بخطأ صريح.
 */
import { createOpenAICompatible } from "@ai-sdk/openai-compatible";
import { streamText } from "ai";
import { getSetting } from "../lib/settings";
import { log } from "../lib/logger";

export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface ChatOptions {
  messages: ChatMessage[];
  signal?: AbortSignal;
  /** صور مرفقة (data URL) — تُمرَّر للنموذج الذي يدعم الرؤية */
  images?: string[];
}

export interface EngineInfo {
  engine: "local" | "remote";
  model: string;
}

async function pickLocalModel(): Promise<string> {
  const { listModels } = await import("../ai/ai-client");
  try {
    const list = await listModels();
    return list.defaultModelId;
  } catch (err) {
    log.warn("listModels failed, using fallback", { error: String(err) });
    return "kimi-k2.5";
  }
}

async function* streamLocal(opts: ChatOptions): AsyncGenerator<string> {
  const baseURL = process.env.KIMI_AGENTGW_BASE_URL;
  const apiKey = process.env.KIMI_AGENTGW_API_KEY;
  if (!baseURL || !apiKey) {
    throw new Error("بوابة الذكاء الاصطناعي غير مهيأة على الخادم (KIMI_AGENTGW)");
  }
  const gateway = createOpenAICompatible({
    name: "kimi-gw",
    baseURL,
    apiKey,
    includeUsage: true,
    supportsStructuredOutputs: true,
  });
  const modelId = await pickLocalModel();
  const aiMessages = opts.messages.map((m) => {
    if (m.role === "user" && opts.images && opts.images.length > 0) {
      return {
        role: "user" as const,
        content: [
          { type: "text" as const, text: m.content },
          ...opts.images.map((url) => ({ type: "image" as const, image: url })),
        ],
      };
    }
    return { role: m.role, content: m.content };
  });
  const result = streamText({
    model: gateway(modelId),
    messages: aiMessages as never,
    abortSignal: opts.signal,
    providerOptions: { "kimi-gw": { max_completion_tokens: 4096 } },
  });
  for await (const part of result.textStream) {
    yield part;
  }
  // نهاية غير مكتملة (انقطاع بلا [DONE]) تُعامَل كفشل
  if (opts.signal?.aborted) return;
  const final = await result.text;
  if (!final && !opts.signal?.aborted) {
    throw new Error("أُغلق البث قبل اكتمال الإجابة");
  }
}

async function* streamRemote(url: string, key: string, opts: ChatOptions): AsyncGenerator<string> {
  const base = url.replace(/\/+$/, "");
  const res = await fetch(`${base}/v1/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(key ? { Authorization: `Bearer ${key}` } : {}),
    },
    body: JSON.stringify({
      model: await getSetting("remote_model").catch(() => "") || undefined,
      messages: opts.messages,
      stream: true,
    }),
    signal: opts.signal,
  });
  if (!res.ok || !res.body) {
    const text = await res.text().catch(() => "");
    throw new Error(`السيرفر الخاص أعاد خطأً (${res.status}): ${text.slice(0, 200)}`);
  }
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        const t = line.trim();
        if (!t.startsWith("data:")) continue;
        const payload = t.slice(5).trim();
        if (payload === "[DONE]") return;
        try {
          const json = JSON.parse(payload);
          const delta = json.choices?.[0]?.delta?.content;
          if (typeof delta === "string" && delta) yield delta;
        } catch {
          // سطر غير مكتمل — سيُعالج مع الـ buffer التالي
        }
      }
    }
  } finally {
    reader.cancel().catch(() => undefined);
  }
}

/** يولّد رد النموذج حسب المحرك المختار في الإعدادات */
export async function* chat(opts: ChatOptions): AsyncGenerator<string> {
  const engine = (await getSetting("engine")) || "local";
  if (engine === "remote") {
    const url = await getSetting("remote_url");
    if (!url) throw new Error("لم يُضبط عنوان السيرفر الخاص بعد — فعّله من الإعدادات");
    const key = await getSetting("remote_key");
    yield* streamRemote(url, key, opts);
  } else {
    yield* streamLocal(opts);
  }
}

/** معلومات المحرك الحالي (للعرض في الواجهة) */
export async function engineInfo(): Promise<EngineInfo> {
  const engine = ((await getSetting("engine")) || "local") as EngineInfo["engine"];
  if (engine === "remote") {
    return { engine, model: await getSetting("remote_model") || "llama.cpp" };
  }
  return { engine, model: "kimi-gateway" };
}
