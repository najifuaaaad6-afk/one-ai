export * from "./errors";

/** أنواع مشتركة بين الواجهة والخادم */
export interface ConversationMeta {
  id: string;
  title: string;
  created_at: number;
  updated_at: number;
  pinned: number;
}

export interface ChatMessageView {
  id: string;
  role: string;
  content: string;
  status: string;
  attachments: string;
  created_at: number;
}

export interface ModelView {
  id: string;
  level: string;
  name: string;
  repo: string;
  filename: string;
  url: string;
  size_bytes: number;
  sha256: string;
  status: string;
  progress_bytes: number;
  percent: number;
  path: string;
  error: string;
}

export interface SkillView {
  id: string;
  name: string;
  name_ar: string;
  description: string;
  description_ar: string;
  prompt: string;
  builtin: number;
  enabled: number;
  created_at: number;
  knowledge: { id: string; filename: string; created_at: number }[];
}

export interface FileView {
  id: string;
  filename: string;
  mime: string;
  size: number;
  kind: string;
  created_at: number;
  hasText: boolean;
}
