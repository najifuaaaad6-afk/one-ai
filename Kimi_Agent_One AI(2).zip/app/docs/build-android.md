# بناء تطبيق Android / APK

One AI تطبيق ويب كامل الوظائف (React + خادم Node + SQLite). لتحويله إلى APK مثبّت على Android هناك مساران واقعيان:

## المسار 1 — Capacitor (موصى به): غلاف أصلي حول نفس الكود

الواجهة الحالية تصلح كما هي. تحتاج فقط إلى استضافة الخادم على جهازك/شبكتك:

```bash
npm install
npm run build          # ينتج dist/public + dist/boot.js
NODE_ENV=production node dist/boot.js   # يعمل على 0.0.0.0:3000
```

ثم غلّف الواجهة:

```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "One AI" com.oneai.app --web-dir=dist/public
# اجعل التطبيق يشير إلى عنوان خادمك (IP محلي عبر Tailscale/الشبكة المنزلية)
npx cap add android
npx cap sync
npx cap open android   # يفتح Android Studio ← Build ← Build APK
```

النتيجة: APK أصلي، الواجهة نفسها، والبيانات على خادمك. لتجربة الهاتف فعلياً استخدم `llama.cpp` على الكمبيوتر كسيرفر خاص — هذا هو «وضع السيرفر الخاص» الموجود في الإعدادات.

## المسار 2 — Python أصلي على الجهاز (Kivy + Chaquopy)

طلبك يذكر Python كلغة أساسية. محركات الذكاء الاصطناعي هنا مكتوبة فعلاً بواجهات Python-صديقة عبر خادم llama.cpp (الذي تشغّله بأمر واحد)، لكن تشغيل Python *داخل* Android مع محرك استدلال كامل هو مشروع مستقل:

- **Chaquopy**: يتيح تشغيل Python داخل تطبيق Android (Java/Kotlin + Python)، لكنه لا يحل تحويل الواجهة تلقائياً.
- **Kivy + Buildozer**: واجهات Python أصلية — تعني إعادة كتابة كل الواجهة الحالية من الصفر.
- **llama.cpp** (الذي يشغّل نماذج GGUF): مكتوب C/C++ مع ربط Python رسمي (`llama-cpp-python`). على Android يُبنى عبر NDK — ثقيل لكنه المسار الأصح لتشغيل نموذج *على* الهاتف نفسه.

الخطة الواقعية للمرحلة التالية إن أردت تشغيلاً كاملاً دون خادم خارجي:
1. تثبيت Termux على الهاتف أو بناء تطبيق Kivy/Chaquopy.
2. تشغيل `llama-server` (مبني لـ Android) على منفذ محلي داخل الجهاز: `./llama-server -m model.gguf --port 8080`.
3. جعل One AI يتصل بـ `http://127.0.0.1:8080` — وضع «السيرفر الخاص» يدعم هذا فوراً دون تعديل كود.

## بيئة البناء المطلوبة

- Android Studio + SDK 34، JDK 17.
- للمسار الثاني: NDK + Buildozer (Linux) أو p4a.

> ملاحظة صدق: بيئة تطوير هذه تسلّم تطبيق ويب قابل للبناء والمعاينة الفورية، ولا تنتج APK مباشرة. الخطوات أعلاه هي التسلسل الكامل المعتمد لإنتاج APK من هذا الكود.
